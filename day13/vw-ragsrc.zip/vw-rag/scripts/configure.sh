#!/usr/bin/env bash
set -euo pipefail

INSIGHTS_CONN=$(az monitor app-insights component show \
  --app $INSIGHTS -g $RG --query connectionString -o tsv)

az webapp config appsettings set -n $API -g $RG --settings \
  AZURE_SEARCH_ENDPOINT="https://$SEARCH.search.windows.net" \
  AZURE_SEARCH_INDEX="vw-knowledge" \
  AZURE_OPENAI_ENDPOINT="https://$AOAI.openai.azure.com" \
  AZURE_OPENAI_CHAT_DEPLOYMENT="gpt-4o" \
  AZURE_OPENAI_EMBED_DEPLOYMENT="text-embedding-3-large" \
  EMBED_DIMENSIONS="3072" \
  APPLICATIONINSIGHTS_CONNECTION_STRING="$INSIGHTS_CONN"

# Tell App Service how to boot FastAPI (gunicorn + uvicorn workers)
az webapp config set -n $API -g $RG \
  --startup-file "gunicorn -w 2 -k uvicorn.workers.UvicornWorker app:app"

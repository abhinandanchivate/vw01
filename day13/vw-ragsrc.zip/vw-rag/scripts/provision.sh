#!/usr/bin/env bash
set -euo pipefail

# ---------- 0. Variables ----------
LOCATION=westeurope
RG=rg-vw-rag
PREFIX=vwrag$RANDOM                 # keep it short & lowercase (storage rules)
STORAGE=${PREFIX}stg
SEARCH=${PREFIX}-search
AOAI=${PREFIX}-aoai
VAULT=${PREFIX}-kv
PLAN=${PREFIX}-plan
API=${PREFIX}-api
INGEST=${PREFIX}-ingest
INSIGHTS=${PREFIX}-ai

az login
az account set --subscription "<YOUR_SUBSCRIPTION_ID>"

# ---------- 1. Resource group ----------
az group create -n $RG -l $LOCATION

# ---------- 2. Storage account + documents container ----------
az storage account create -n $STORAGE -g $RG -l $LOCATION \
  --sku Standard_LRS --kind StorageV2 --min-tls-version TLS1_2
az storage container create --account-name $STORAGE -n vw-documents --auth-mode login

# ---------- 3. Azure AI Search (hosts the vector index) ----------
az search service create -n $SEARCH -g $RG -l $LOCATION \
  --sku standard --partition-count 1 --replica-count 1
# Turn on Entra ID (RBAC) data-plane auth so we can use managed identity
az search service update -n $SEARCH -g $RG \
  --auth-options aadOrApiKey --aad-auth-failure-mode http401WithBearerChallenge

# ---------- 4. Azure OpenAI + model deployments ----------
az cognitiveservices account create -n $AOAI -g $RG -l $LOCATION \
  --kind OpenAI --sku S0 --custom-domain $AOAI
az cognitiveservices account deployment create -g $RG -n $AOAI \
  --deployment-name text-embedding-3-large \
  --model-name text-embedding-3-large --model-version "1" \
  --model-format OpenAI --sku-name Standard --sku-capacity 50
az cognitiveservices account deployment create -g $RG -n $AOAI \
  --deployment-name gpt-4o \
  --model-name gpt-4o --model-version "2024-08-06" \
  --model-format OpenAI --sku-name Standard --sku-capacity 30

# ---------- 5. Key Vault (RBAC mode) ----------
az keyvault create -n $VAULT -g $RG -l $LOCATION --enable-rbac-authorization true

# ---------- 6. Application Insights ----------
az monitor app-insights component create \
  --app $INSIGHTS -g $RG -l $LOCATION --application-type web

# ---------- 7. API host: Linux App Service ----------
az appservice plan create -n $PLAN -g $RG --is-linux --sku P1v3
az webapp create -n $API -g $RG -p $PLAN --runtime "PYTHON:3.12"

# ---------- 8. Ingestion host: Function App (event-driven) ----------
az functionapp create -n $INGEST -g $RG \
  --storage-account $STORAGE --consumption-plan-location $LOCATION \
  --runtime python --runtime-version 3.12 --functions-version 4 --os-type Linux

# ---------- 9. Managed identities (no secrets needed) ----------
az webapp identity assign -n $API -g $RG
az functionapp identity assign -n $INGEST -g $RG

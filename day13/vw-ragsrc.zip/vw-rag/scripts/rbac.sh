#!/usr/bin/env bash
set -euo pipefail

# Principal IDs of the two managed identities
API_PID=$(az webapp identity show -n $API -g $RG --query principalId -o tsv)
ING_PID=$(az functionapp identity show -n $INGEST -g $RG --query principalId -o tsv)

# Resource scope IDs
SEARCH_ID=$(az search service show -n $SEARCH -g $RG --query id -o tsv)
AOAI_ID=$(az cognitiveservices account show -n $AOAI -g $RG --query id -o tsv)
STG_ID=$(az storage account show -n $STORAGE -g $RG --query id -o tsv)
KV_ID=$(az keyvault show -n $VAULT -g $RG --query id -o tsv)

# Azure AI Search (data plane)
az role assignment create --assignee $ING_PID \
  --role "Search Index Data Contributor" --scope $SEARCH_ID
az role assignment create --assignee $API_PID \
  --role "Search Index Data Reader" --scope $SEARCH_ID

# Azure OpenAI (inference)
az role assignment create --assignee $ING_PID \
  --role "Cognitive Services OpenAI User" --scope $AOAI_ID
az role assignment create --assignee $API_PID \
  --role "Cognitive Services OpenAI User" --scope $AOAI_ID

# Storage (read documents) + Key Vault (read secrets)
az role assignment create --assignee $ING_PID \
  --role "Storage Blob Data Reader" --scope $STG_ID
az role assignment create --assignee $API_PID \
  --role "Key Vault Secrets User" --scope $KV_ID

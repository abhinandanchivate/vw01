#!/usr/bin/env bash
set -euo pipefail

# Create the search index once (uses your local az-login credentials)
python index_create.py

# Deploy the FastAPI app (zip deploy)
cd api && zip -r ../api.zip . && cd ..
az webapp deploy -n $API -g $RG --src-path api.zip --type zip

# Deploy the ingestion Function App (Azure Functions Core Tools)
cd ingest && func azure functionapp publish $INGEST && cd ..

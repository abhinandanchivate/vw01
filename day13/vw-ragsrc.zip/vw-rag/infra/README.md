# Infrastructure

The explicit, readable build lives in **`../scripts/`** as Azure CLI scripts.
Run them in order:

1. `scripts/provision.sh`  – create all Azure resources + model deployments
2. `scripts/rbac.sh`       – grant least-privilege data-plane roles to the managed identities
3. `scripts/configure.sh`  – set app settings (endpoints, deployment names, App Insights)
4. `scripts/deploy.sh`     – create the search index, deploy the API and the Function App

For repeatable, environment-per-stage provisioning, port the same resources to
**Bicep** and deploy with the **Azure Developer CLI** (`azd up`), which provisions
infrastructure and pushes both the API and the Function App in one command.

# app.py — FastAPI service exposing the RAG pipeline.
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from rag import answer_question

app = FastAPI(title="VW Knowledge Assistant", version="1.0.0")

class AskRequest(BaseModel):
    question: str = Field(min_length=3, max_length=1000)
    vehicle_model: str | None = None

class Source(BaseModel):
    n: int
    document: str
    page: int | None = None

class AskResponse(BaseModel):
    question: str
    answer: str
    sources: list[Source]

@app.get("/health")
def health() -> dict:
    return {"status": "ok"}

@app.post("/ask", response_model=AskResponse)
def ask(req: AskRequest) -> AskResponse:
    try:
        result = answer_question(req.question, req.vehicle_model)
    except Exception as exc:                          # logged to App Insights
        raise HTTPException(status_code=502, detail=str(exc))
    return AskResponse(question=req.question, **result)

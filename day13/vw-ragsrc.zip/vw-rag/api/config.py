# config.py — central configuration, loaded from environment variables.
import os
from functools import lru_cache
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    # Azure AI Search
    search_endpoint: str = os.getenv("AZURE_SEARCH_ENDPOINT", "")
    search_index: str = os.getenv("AZURE_SEARCH_INDEX", "vw-knowledge")

    # Azure OpenAI
    aoai_endpoint: str = os.getenv("AZURE_OPENAI_ENDPOINT", "")
    aoai_api_version: str = os.getenv("AZURE_OPENAI_API_VERSION", "2024-10-21")
    chat_deployment: str = os.getenv("AZURE_OPENAI_CHAT_DEPLOYMENT", "gpt-4o")
    embed_deployment: str = os.getenv("AZURE_OPENAI_EMBED_DEPLOYMENT", "text-embedding-3-large")
    embed_dimensions: int = int(os.getenv("EMBED_DIMENSIONS", "3072"))

    # Sources
    blob_account_url: str = os.getenv("BLOB_ACCOUNT_URL", "")
    blob_container: str = os.getenv("BLOB_CONTAINER", "vw-documents")
    sql_connection: str = os.getenv("SQL_CONNECTION", "")

    # Retrieval
    top_k: int = int(os.getenv("TOP_K", "8"))
    rerank_k: int = int(os.getenv("RERANK_K", "4"))

    class Config:
        env_file = ".env"


@lru_cache
def get_settings() -> Settings:
    return Settings()

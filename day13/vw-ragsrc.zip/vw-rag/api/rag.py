# rag.py — the full Retrieval-Augmented Generation flow.
from retrieval import retrieve, build_filter
from prompt import build_messages
from generate import generate

def answer_question(question: str, vehicle_model: str | None = None) -> dict:
    filters = build_filter(vehicle_model=vehicle_model)
    hits = retrieve(question, filters=filters)
    if not hits:
        return {"answer": "No relevant Volkswagen documentation was found.",
                "sources": []}
    answer = generate(build_messages(question, hits))
    sources = [{"n": i + 1, "document": h["document_name"], "page": h.get("page")}
               for i, h in enumerate(hits)]
    return {"answer": answer, "sources": sources}

if __name__ == "__main__":
    result = answer_question(
        "My Volkswagen Taigun takes longer to start and battery voltage is "
        "11.4V. What should I inspect?",
        vehicle_model="Taigun",
    )
    print(result["answer"])

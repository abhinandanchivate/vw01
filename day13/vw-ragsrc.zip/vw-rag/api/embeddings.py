# embeddings.py — generate vectors with Azure OpenAI (batch-friendly).
from openai import AzureOpenAI
from auth import aoai_token_provider
from config import get_settings

settings = get_settings()
_client = AzureOpenAI(
    azure_endpoint=settings.aoai_endpoint,
    api_version=settings.aoai_api_version,
    azure_ad_token_provider=aoai_token_provider,    # managed identity, no keys
)

def embed(texts: list[str]) -> list[list[float]]:
    """Embed a batch. text-embedding-3-large -> 3072 dims by default."""
    resp = _client.embeddings.create(
        model=settings.embed_deployment,
        input=texts,
        dimensions=settings.embed_dimensions,
    )
    return [item.embedding for item in resp.data]

def embed_one(text: str) -> list[float]:
    return embed([text])[0]

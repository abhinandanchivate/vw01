# prompt.py — system prompt + context assembly with citation anchors.
SYSTEM_PROMPT = (
    "You are a Volkswagen service knowledge assistant. Answer ONLY from the "
    "provided context. If the context does not contain the answer, say so "
    "plainly. Never invent part numbers, torque values, or procedures. Cite "
    "every factual claim with its [n] source marker. Always end with the "
    "disclaimer that a qualified technician must validate any diagnosis."
)

def build_messages(question: str, hits: list[dict]) -> list[dict]:
    blocks = []
    for i, hit in enumerate(hits, start=1):
        loc = f", p.{hit['page']}" if hit.get("page") else ""
        blocks.append(f"[{i}] (source: {hit['document_name']}{loc})\n{hit['content']}")
    context = "\n\n".join(blocks)
    user = (
        f"Context:\n{context}\n\n"
        f"Question: {question}\n\n"
        "Answer with: (1) a direct answer, (2) recommended inspections as a "
        "numbered list, (3) the [n] sources used, (4) the technician-validation "
        "disclaimer."
    )
    return [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": user},
    ]

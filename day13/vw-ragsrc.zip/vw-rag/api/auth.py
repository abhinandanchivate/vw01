# auth.py — single source of truth for Azure credentials. Uses the app's
# managed identity in the cloud and your developer login locally. No keys.
from azure.identity import DefaultAzureCredential, get_bearer_token_provider

_credential = DefaultAzureCredential()

# Bearer-token provider for Azure OpenAI data-plane calls.
aoai_token_provider = get_bearer_token_provider(
    _credential, "https://cognitiveservices.azure.com/.default"
)

def credential() -> DefaultAzureCredential:
    return _credential

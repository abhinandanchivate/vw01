# generate.py — call the chat model with low temperature for faithfulness.
from openai import AzureOpenAI
from auth import aoai_token_provider
from config import get_settings

settings = get_settings()
_client = AzureOpenAI(
    azure_endpoint=settings.aoai_endpoint,
    api_version=settings.aoai_api_version,
    azure_ad_token_provider=aoai_token_provider,
)

def generate(messages: list[dict]) -> str:
    resp = _client.chat.completions.create(
        model=settings.chat_deployment,
        messages=messages,
        temperature=0.1,         # low -> deterministic, grounded
        max_tokens=800,
    )
    return resp.choices[0].message.content

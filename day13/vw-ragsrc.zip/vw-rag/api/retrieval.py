# retrieval.py — hybrid search (vector + keyword) with metadata filters,
# refined by the Azure AI Search semantic reranker.
from azure.search.documents import SearchClient
from azure.search.documents.models import VectorizedQuery
from auth import credential
from config import get_settings
from embeddings import embed_one

settings = get_settings()
_client = SearchClient(settings.search_endpoint, settings.search_index, credential())

def retrieve(question: str, filters: str | None = None) -> list[dict]:
    vector_query = VectorizedQuery(
        vector=embed_one(question),
        k_nearest_neighbors=settings.top_k,
        fields="content_vector",
    )
    results = _client.search(
        search_text=question,                 # keyword/BM25 leg of the hybrid
        vector_queries=[vector_query],        # vector leg of the hybrid
        filter=filters,                       # e.g. "vehicle_model eq 'Taigun'"
        query_type="semantic",                # semantic reranker
        semantic_configuration_name="semantic-config",
        top=settings.rerank_k,
        select=["id", "content", "document_name", "doc_type", "page"],
    )
    return [{
        "id": r["id"],
        "content": r["content"],
        "document_name": r["document_name"],
        "page": r.get("page"),
        "score": r.get("@search.reranker_score", r["@search.score"]),
    } for r in results]

def build_filter(vehicle_model: str | None = None,
                 doc_type: str | None = None) -> str | None:
    clauses = []
    if vehicle_model:
        clauses.append(f"vehicle_model eq '{vehicle_model}'")
    if doc_type:
        clauses.append(f"doc_type eq '{doc_type}'")
    return " and ".join(clauses) or None

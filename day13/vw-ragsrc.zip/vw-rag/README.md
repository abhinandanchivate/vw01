# VW Enterprise RAG — Knowledge Assistant

A Retrieval-Augmented Generation system that answers questions from Volkswagen's
own technical documentation (SharePoint, Blob Storage, SQL Server, internal
repository) and returns grounded, **cited** answers — refusing when the indexed
content does not contain the answer.

This is the reference implementation that accompanies the solution case study.

---

## Repository layout

```
vw-rag/
├── api/                  # Serving tier  → Azure App Service (FastAPI)
│   ├── app.py            # FastAPI entrypoint  (POST /ask, GET /health)
│   ├── rag.py            # retrieve → prompt → generate
│   ├── retrieval.py      # hybrid search (vector + keyword + semantic rerank)
│   ├── prompt.py         # grounding prompt + citation anchors
│   ├── generate.py       # Azure OpenAI chat call
│   ├── embeddings.py     # (shared) text → vectors
│   ├── auth.py           # (shared) managed-identity credential
│   ├── config.py         # (shared) settings from env
│   └── requirements.txt
├── ingest/               # Indexing tier → Azure Functions (event-driven)
│   ├── function_app.py   # blob-trigger: re-index a document on upload
│   ├── ingest.py         # orchestration: read → clean → chunk → index
│   ├── chunking.py       # token-bounded, overlapping chunks (tiktoken)
│   ├── nlp.py            # light normalization + entity → metadata
│   ├── index_create.py   # define the Azure AI Search index
│   ├── index_upsert.py   # embed + upsert chunks
│   ├── chroma_dev.py     # OPTIONAL local/offline vector store (PoC only)
│   ├── embeddings.py     # (shared)
│   ├── auth.py           # (shared)
│   ├── config.py         # (shared)
│   ├── host.json
│   ├── requirements.txt
│   └── sources/          # one reader per source system
│       ├── blob.py        sharepoint.py  sql.py  files.py  ocr.py
├── scripts/              # Azure CLI build (run in order: provision → rbac → configure → deploy)
├── infra/                # IaC notes (Bicep / azd)
└── docs/                 # architecture diagrams
```

> **Shared modules.** `config.py`, `auth.py`, and `embeddings.py` are intentionally
> duplicated in `api/` and `ingest/` so each tier deploys as a self-contained unit
> (the App Service zip and the Function App are published separately). Keep the two
> copies in sync, or factor them into a shared wheel if you prefer.

---

## Prerequisites

- Python 3.11+ (3.12 recommended)
- An Azure subscription with the **Azure CLI** (`az`) signed in
- **Azure Functions Core Tools** (`func`) to deploy the ingestion tier
- Approved access to **Azure OpenAI** in your region, with model quota
- For SQL Server: the **ODBC Driver 18 for SQL Server**

---

## Configuration

All configuration comes from environment variables; no secrets live in code.
Copy the example file and fill in your values:

```bash
cp .env.example .env        # (also copy into api/ and ingest/ when running each tier)
```

Authentication uses **managed identity** in Azure and your **developer login**
locally (`DefaultAzureCredential`). Locally, sign in once with `az login`.

---

## Quick start (local)

The serving code talks to Azure AI Search and Azure OpenAI, so the simplest path
to a working demo is to provision the (cheap-tier) Azure resources first — see
**Deploy to Azure** below — then run locally against them:

```bash
# 1) install
cd api && python -m pip install -r requirements.txt && cd ..
cd ingest && python -m pip install -r requirements.txt && python -m spacy download en_core_web_sm && cd ..

# 2) create the index + ingest documents
cd ingest && python index_create.py && python ingest.py && cd ..

# 3) run the API
cd api && uvicorn app:app --reload --port 8000
```

Test it:

```bash
curl -X POST http://localhost:8000/ask \
  -H "Content-Type: application/json" \
  -d '{"question":"Taigun longer to start, battery 11.4V. What to inspect?","vehicle_model":"Taigun"}'
```

**No-cost experimentation.** `ingest/chroma_dev.py` is a local, offline vector
store (ChromaDB + a sentence-transformer) with the same `upsert/search` shape as
Azure AI Search. Use it to experiment with chunking and retrieval without any
Azure resources, then promote to Azure AI Search for production.

---

## Deploy to Azure

Run the scripts in order (review and set your subscription id first):

```bash
bash scripts/provision.sh     # resource group, Storage, AI Search, Azure OpenAI (+ deployments),
                              # Key Vault, App Insights, App Service, Function App, managed identities
bash scripts/rbac.sh          # least-privilege data-plane role assignments
bash scripts/configure.sh     # app settings: endpoints, deployment names, App Insights
bash scripts/deploy.sh        # create the index, deploy the API and the Function App
```

After deployment, uploading a document to the `vw-documents` blob container
triggers `ingest/function_app.py`, which re-indexes it automatically.

---

## Security notes

- Managed identity end-to-end — no keys or connection strings in code or app settings.
- Each identity holds only the roles it needs (Search read vs write, OpenAI user,
  Storage read, Key Vault secrets user), scoped to single resources.
- For production, place Azure OpenAI, AI Search, and Storage behind Private
  Endpoints, put the API behind Microsoft Entra ID, and security-trim retrieval
  so users only see passages they are entitled to.

The model is instructed to answer **only** from retrieved context, to cite every
claim, and to refuse when the answer is absent — decision support that always
keeps a qualified technician in the loop.

# function_app.py — Function App that re-indexes a blob the moment it lands.
import azure.functions as func
from ingest import ingest_blob_document

app = func.FunctionApp()

@app.blob_trigger(arg_name="blob",
                  path="vw-documents/{name}",
                  connection="AzureWebJobsStorage")
def on_new_document(blob: func.InputStream):
    name = blob.name.split("/", 1)[-1]
    indexed = ingest_blob_document(name)
    import logging
    logging.info("Indexed %s chunks from %s", indexed, name)

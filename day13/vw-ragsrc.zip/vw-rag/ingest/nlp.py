# nlp.py — LIGHT normalization for embedding + metadata enrichment.
#
# IMPORTANT: modern dense embedding models are trained on natural, cased text.
# Do NOT lowercase, strip punctuation, or delete numbers/units before
# embedding — that destroys signal ("11.4V", "Taigun", "P0562"). Clean only
# genuine noise: encoding artefacts, broken line wraps, repeated boilerplate.
import re
import unicodedata
import spacy

_nlp = spacy.load("en_core_web_sm", disable=["lemmatizer"])  # keep the NER pipe
_LIGATURES = {"\ufb01": "fi", "\ufb02": "fl"}

def normalize_text(text: str) -> str:
    text = unicodedata.normalize("NFKC", text)
    for bad, good in _LIGATURES.items():
        text = text.replace(bad, good)
    text = re.sub(r"(\w)-\n(\w)", r"\1\2", text)   # de-hyphenate line wraps
    text = re.sub(r"[ \t]+", " ", text)            # collapse spaces
    text = re.sub(r"\n{3,}", "\n\n", text)         # keep paragraph breaks only
    return text.strip()

# Entity labels worth keeping as FILTERABLE METADATA (never mutate the text).
_KEEP_LABELS = {"PRODUCT", "ORG", "QUANTITY", "CARDINAL", "DATE"}

def extract_entities(text: str) -> dict:
    doc = _nlp(text[:100_000])                     # cap input to protect latency
    ents: dict[str, list[str]] = {}
    for ent in doc.ents:
        if ent.label_ in _KEEP_LABELS:
            bucket = ents.setdefault(ent.label_, [])
            if ent.text not in bucket:
                bucket.append(ent.text)
    return ents

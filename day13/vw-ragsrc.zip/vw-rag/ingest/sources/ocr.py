# sources/ocr.py — OCR for scanned PDFs with Azure AI Document Intelligence.
import os
from azure.ai.documentintelligence import DocumentIntelligenceClient
from auth import credential

_client = DocumentIntelligenceClient(
    endpoint=os.environ["AZURE_DOCINTEL_ENDPOINT"], credential=credential()
)

def ocr_pdf(data: bytes) -> str:
    poller = _client.begin_analyze_document("prebuilt-read", body=data)
    return poller.result().content or ""

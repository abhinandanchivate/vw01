# sources/blob.py — stream documents from Azure Blob Storage.
from azure.storage.blob import BlobServiceClient
from auth import credential
from config import get_settings

settings = get_settings()

def list_documents():
    client = BlobServiceClient(settings.blob_account_url, credential())
    container = client.get_container_client(settings.blob_container)
    for blob in container.list_blobs():
        yield blob.name

def download_document(blob_name: str) -> bytes:
    client = BlobServiceClient(settings.blob_account_url, credential())
    blob = client.get_blob_client(settings.blob_container, blob_name)
    return blob.download_blob().readall()

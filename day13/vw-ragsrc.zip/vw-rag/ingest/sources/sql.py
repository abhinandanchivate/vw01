# sources/sql.py — read structured rows (e.g. service history) and turn each
# row into a self-describing text record for embedding.
import pandas as pd
from sqlalchemy import create_engine, text
from config import get_settings

settings = get_settings()
_engine = create_engine(settings.sql_connection, pool_pre_ping=True)

SERVICE_QUERY = text("""
    SELECT vehicle_model, model_year, complaint, diagnostic_code,
           resolution, service_date
    FROM dbo.service_history
""")

def fetch_service_history() -> pd.DataFrame:
    with _engine.connect() as conn:
        return pd.read_sql(SERVICE_QUERY, conn)

def row_to_record(row: pd.Series) -> dict:
    text_blob = (
        f"Vehicle model: {row.vehicle_model} ({row.model_year}). "
        f"Complaint: {row.complaint}. "
        f"Diagnostic code: {row.diagnostic_code}. "
        f"Resolution: {row.resolution}. "
        f"Service date: {row.service_date:%Y-%m-%d}."
    )
    return {
        "text": text_blob,
        "metadata": {
            "source": "sql:service_history",
            "doc_type": "service_record",
            "vehicle_model": row.vehicle_model,
            "page": None,
        },
    }

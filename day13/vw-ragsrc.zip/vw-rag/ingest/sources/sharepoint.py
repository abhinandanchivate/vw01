# sources/sharepoint.py — pull files from a SharePoint document library via
# Microsoft Graph, authenticated with the app's Entra identity.
import requests
from auth import credential

GRAPH = "https://graph.microsoft.com/v1.0"

def _headers() -> dict:
    token = credential().get_token("https://graph.microsoft.com/.default").token
    return {"Authorization": f"Bearer {token}"}

def list_drive_items(site_id: str, drive_id: str):
    url = f"{GRAPH}/sites/{site_id}/drives/{drive_id}/root/children"
    while url:
        resp = requests.get(url, headers=_headers(), timeout=30)
        resp.raise_for_status()
        data = resp.json()
        for item in data.get("value", []):
            if "file" in item:                       # skip folders
                yield item
        url = data.get("@odata.nextLink")             # paginate

def download_item(item: dict) -> bytes:
    return requests.get(item["@microsoft.graph.downloadUrl"], timeout=60).content

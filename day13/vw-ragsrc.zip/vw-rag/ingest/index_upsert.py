# index_upsert.py — push embedded chunks into the search index.
import hashlib
from azure.search.documents import SearchClient
from auth import credential
from config import get_settings
from embeddings import embed

settings = get_settings()
_client = SearchClient(settings.search_endpoint, settings.search_index, credential())

def _doc_id(document_name: str, i: int) -> str:
    return hashlib.sha1(f"{document_name}-{i}".encode()).hexdigest()

def upsert_chunks(chunks: list[str], metadata: dict) -> int:
    vectors = embed(chunks)                          # one batch call
    payload = [{
        "id": _doc_id(metadata["document_name"], i),
        "content": chunk,
        "content_vector": vector,
        **{k: metadata.get(k) for k in
           ("source", "doc_type", "document_name", "vehicle_model", "page")},
    } for i, (chunk, vector) in enumerate(zip(chunks, vectors))]

    result = _client.merge_or_upload_documents(documents=payload)
    return sum(1 for r in result if r.succeeded)

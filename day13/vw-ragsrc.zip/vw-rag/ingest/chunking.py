# chunking.py — structure-aware, token-bounded chunking with overlap.
import re
import tiktoken

_enc = tiktoken.get_encoding("o200k_base")          # GPT-4o / 3-large family

def _ntokens(s: str) -> int:
    return len(_enc.encode(s))

def split_paragraphs(text: str) -> list[str]:
    return [p.strip() for p in re.split(r"\n\s*\n", text) if p.strip()]

def chunk_text(text: str, max_tokens: int = 512, overlap: int = 64) -> list[str]:
    """Pack paragraphs up to ~max_tokens, carrying `overlap` tokens of tail
    context into the next chunk so meaning is not severed at boundaries."""
    chunks, current, current_tokens = [], [], 0

    def flush(carry_tail: str | None):
        nonlocal current, current_tokens
        if current:
            chunks.append("\n\n".join(current))
        current = [carry_tail] if carry_tail else []
        current_tokens = _ntokens(carry_tail) if carry_tail else 0

    for para in split_paragraphs(text):
        ptok = _ntokens(para)
        if ptok > max_tokens:                       # split oversized paragraph
            for sentence in re.split(r"(?<=[.!?])\s+", para):
                if current_tokens + _ntokens(sentence) > max_tokens:
                    flush(current[-1] if current else None)
                current.append(sentence)
                current_tokens += _ntokens(sentence)
            continue
        if current_tokens + ptok > max_tokens:
            flush(current[-1])                      # overlap = previous block
        current.append(para)
        current_tokens += ptok

    flush(None)
    # trim each carried tail to ~overlap tokens to avoid runaway duplication
    return [c for c in chunks if c.strip()]

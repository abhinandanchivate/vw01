# chroma_dev.py — zero-cost LOCAL vector store for development / PoC only.
# Same upsert/search shape as production, so swapping to Azure AI Search is easy.
import chromadb
from sentence_transformers import SentenceTransformer

_model = SentenceTransformer("all-MiniLM-L6-v2")     # 384-dim, fully offline
_client = chromadb.PersistentClient(path="./.chroma")
_collection = _client.get_or_create_collection("vw_knowledge")

def upsert_chunks(chunks: list[str], metadata: dict):
    embeddings = _model.encode(chunks).tolist()
    ids = [f"{metadata['document_name']}-{i}" for i in range(len(chunks))]
    metadatas = [metadata | {"chunk": i} for i in range(len(chunks))]
    _collection.upsert(ids=ids, embeddings=embeddings,
                       documents=chunks, metadatas=metadatas)

def search(query: str, k: int = 8):
    qvec = _model.encode(query).tolist()
    return _collection.query(query_embeddings=[qvec], n_results=k)

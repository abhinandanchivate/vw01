# index_create.py — define the Azure AI Search index (vector + hybrid + semantic).
from azure.search.documents.indexes import SearchIndexClient
from azure.search.documents.indexes.models import (
    SearchIndex, SimpleField, SearchableField, SearchField, SearchFieldDataType,
    VectorSearch, HnswAlgorithmConfiguration, VectorSearchProfile,
    SemanticSearch, SemanticConfiguration, SemanticPrioritizedFields, SemanticField,
)
from auth import credential
from config import get_settings

settings = get_settings()

def build_index() -> SearchIndex:
    fields = [
        SimpleField(name="id", type=SearchFieldDataType.String, key=True),
        SearchableField(name="content", type=SearchFieldDataType.String),
        SearchField(
            name="content_vector",
            type=SearchFieldDataType.Collection(SearchFieldDataType.Single),
            searchable=True,
            vector_search_dimensions=settings.embed_dimensions,
            vector_search_profile_name="hnsw-profile",
        ),
        SimpleField(name="source",         type=SearchFieldDataType.String, filterable=True, facetable=True),
        SimpleField(name="doc_type",       type=SearchFieldDataType.String, filterable=True, facetable=True),
        SimpleField(name="document_name",  type=SearchFieldDataType.String, filterable=True),
        SimpleField(name="vehicle_model",  type=SearchFieldDataType.String, filterable=True, facetable=True),
        SimpleField(name="page",           type=SearchFieldDataType.Int32,  filterable=True),
    ]
    vector_search = VectorSearch(
        algorithms=[HnswAlgorithmConfiguration(name="hnsw-config")],
        profiles=[VectorSearchProfile(
            name="hnsw-profile", algorithm_configuration_name="hnsw-config")],
    )
    semantic = SemanticSearch(configurations=[
        SemanticConfiguration(
            name="semantic-config",
            prioritized_fields=SemanticPrioritizedFields(
                content_fields=[SemanticField(field_name="content")]),
        )
    ])
    return SearchIndex(name=settings.search_index, fields=fields,
                       vector_search=vector_search, semantic_search=semantic)

def create_index():
    client = SearchIndexClient(settings.search_endpoint, credential())
    client.create_or_update_index(build_index())
    print(f"Index '{settings.search_index}' is ready.")

if __name__ == "__main__":
    create_index()

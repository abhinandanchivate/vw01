# ingest.py — orchestrate: read -> normalize -> enrich -> chunk -> index.
from sources.blob import list_documents, download_document
from sources.files import read_pdf, read_docx, read_html
from sources.sql import fetch_service_history, row_to_record
from nlp import normalize_text, extract_entities
from chunking import chunk_text
from index_upsert import upsert_chunks

def _records_from_blob(name: str) -> list[dict]:
    data = download_document(name)
    ext = name.lower().rsplit(".", 1)[-1]
    if ext == "pdf":
        return [{"text": p["text"], "page": p["page"]} for p in read_pdf(data)]
    if ext in ("docx", "doc"):
        return [{"text": read_docx(data), "page": None}]
    if ext in ("html", "htm"):
        return [{"text": read_html(data), "page": None}]
    return []

def ingest_blob_document(name: str) -> int:
    doc_type = "service_manual" if "manual" in name.lower() else "document"
    total = 0
    for rec in _records_from_blob(name):
        clean = normalize_text(rec["text"])
        if not clean:
            continue
        entities = extract_entities(clean)
        metadata = {
            "source": "blob",
            "doc_type": doc_type,
            "document_name": name,
            "page": rec.get("page"),
            "vehicle_model": (entities.get("PRODUCT") or [None])[0],
        }
        total += upsert_chunks(chunk_text(clean), metadata)
    return total

def ingest_service_history() -> int:
    total = 0
    for idx, row in fetch_service_history().iterrows():
        record = row_to_record(row)
        record["metadata"]["document_name"] = f"service_record_{idx}"
        total += upsert_chunks([record["text"]], record["metadata"])
    return total

if __name__ == "__main__":
    indexed = sum(ingest_blob_document(n) for n in list_documents())
    indexed += ingest_service_history()
    print(f"Indexed {indexed} chunks.")

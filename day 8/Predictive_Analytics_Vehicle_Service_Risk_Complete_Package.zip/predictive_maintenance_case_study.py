"""
Predictive Analytics Case Study
Vehicle Service-Risk Prediction for the Next 30 Days

Install:
    pip install pandas numpy scikit-learn

Run:
    python predictive_maintenance_case_study.py

Input:
    vehicle_predictive_maintenance_sample.csv

Outputs:
    vehicle_risk_predictions.csv
    model_performance_metrics.csv
    predictive_analytics_kpi_summary.csv
    feature_importance.csv
"""

from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.inspection import permutation_importance
from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
)
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder

BASE_DIR = Path(__file__).resolve().parent
DATA_FILE = BASE_DIR / "vehicle_predictive_maintenance_sample.csv"
TARGET = "service_required_next_30_days"
ID_COL = "vehicle_id"
RANDOM_STATE = 42
CLASSIFICATION_THRESHOLD = 0.40

if not DATA_FILE.exists():
    raise FileNotFoundError(
        f"{DATA_FILE.name} was not found. Keep the CSV and Python file in the same folder."
    )

data = pd.read_csv(DATA_FILE)

required_columns = {
    ID_COL,
    TARGET,
    "vehicle_age_years",
    "mileage_km",
    "days_since_last_service",
    "engine_temperature_c",
    "battery_voltage",
    "brake_wear_percent",
    "engine_alerts_30d",
    "vibration_score",
    "fuel_efficiency_kmpl",
    "driving_pattern",
    "region",
}
missing_columns = required_columns.difference(data.columns)
if missing_columns:
    raise ValueError(f"Missing required columns: {sorted(missing_columns)}")

numeric_features = [
    "vehicle_age_years",
    "mileage_km",
    "days_since_last_service",
    "engine_temperature_c",
    "battery_voltage",
    "brake_wear_percent",
    "engine_alerts_30d",
    "vibration_score",
    "fuel_efficiency_kmpl",
]
categorical_features = ["driving_pattern", "region"]

X = data[numeric_features + categorical_features]
y = data[TARGET]
vehicle_ids = data[ID_COL]

numeric_pipeline = Pipeline(
    steps=[("imputer", SimpleImputer(strategy="median"))]
)
categorical_pipeline = Pipeline(
    steps=[
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("onehot", OneHotEncoder(handle_unknown="ignore")),
    ]
)

preprocessor = ColumnTransformer(
    transformers=[
        ("numeric", numeric_pipeline, numeric_features),
        ("categorical", categorical_pipeline, categorical_features),
    ]
)

model = RandomForestClassifier(
    n_estimators=250,
    max_depth=10,
    min_samples_leaf=4,
    class_weight="balanced",
    random_state=RANDOM_STATE,
    n_jobs=-1,
)

pipeline = Pipeline(
    steps=[
        ("preprocessor", preprocessor),
        ("model", model),
    ]
)

X_train, X_test, y_train, y_test, id_train, id_test = train_test_split(
    X,
    y,
    vehicle_ids,
    test_size=0.20,
    stratify=y,
    random_state=RANDOM_STATE,
)

pipeline.fit(X_train, y_train)
y_probability = pipeline.predict_proba(X_test)[:, 1]
y_pred = (y_probability >= CLASSIFICATION_THRESHOLD).astype(int)

accuracy = accuracy_score(y_test, y_pred)
precision = precision_score(y_test, y_pred, zero_division=0)
recall = recall_score(y_test, y_pred, zero_division=0)
f1 = f1_score(y_test, y_pred, zero_division=0)
roc_auc = roc_auc_score(y_test, y_probability)
tn, fp, fn, tp = confusion_matrix(y_test, y_pred).ravel()

metrics = pd.DataFrame(
    [
        ["Accuracy", accuracy, "Overall percentage of correct predictions"],
        ["Precision", precision, "Of vehicles flagged as risky, how many actually required service"],
        ["Recall", recall, "Of vehicles that required service, how many were identified"],
        ["F1 Score", f1, "Balance between precision and recall"],
        ["ROC-AUC", roc_auc, "Ability to rank risky vehicles above non-risky vehicles"],
        ["True Negatives", tn, "Correctly predicted as no service required"],
        ["False Positives", fp, "Flagged for service but did not require it"],
        ["False Negatives", fn, "Required service but was not flagged"],
        ["True Positives", tp, "Correctly identified as service required"],
    ],
    columns=["metric", "value", "business_meaning"],
)
metrics.to_csv(BASE_DIR / "model_performance_metrics.csv", index=False)

predictions = X_test.copy()
predictions.insert(0, ID_COL, id_test.values)
predictions["actual_service_required"] = y_test.values
predictions["predicted_service_required"] = y_pred
predictions["service_risk_probability"] = np.round(y_probability, 4)
predictions["risk_band"] = pd.cut(
    predictions["service_risk_probability"],
    bins=[-0.001, 0.30, 0.60, 1.0],
    labels=["Low", "Medium", "High"],
)
predictions["recommended_action"] = np.select(
    [
        predictions["risk_band"].astype(str).eq("High"),
        predictions["risk_band"].astype(str).eq("Medium"),
    ],
    [
        "Contact customer and schedule inspection within 7 days",
        "Send preventive-service reminder and monitor",
    ],
    default="Continue normal monitoring",
)
predictions = predictions.sort_values("service_risk_probability", ascending=False)
predictions.to_csv(BASE_DIR / "vehicle_risk_predictions.csv", index=False)

importance_result = permutation_importance(
    pipeline,
    X_test,
    y_test,
    scoring="roc_auc",
    n_repeats=8,
    random_state=RANDOM_STATE,
    n_jobs=-1,
)
importance = pd.DataFrame(
    {
        "feature": X_test.columns,
        "importance_mean": importance_result.importances_mean,
        "importance_std": importance_result.importances_std,
    }
).sort_values("importance_mean", ascending=False)
importance.to_csv(BASE_DIR / "feature_importance.csv", index=False)

risk_counts = predictions["risk_band"].value_counts()
kpis = pd.DataFrame(
    [
        ["Total source records", len(data), "All vehicle observations"],
        ["Training records", len(X_train), "Records used for model learning"],
        ["Testing records", len(X_test), "Unseen evaluation records"],
        ["Actual service-required cases in test", int(y_test.sum()), "Observed positive cases"],
        ["Predicted service-required cases", int(y_pred.sum()), "Vehicles flagged by classifier"],
        ["High-risk vehicles", int(risk_counts.get("High", 0)), "Immediate follow-up list"],
        ["Medium-risk vehicles", int(risk_counts.get("Medium", 0)), "Preventive reminder list"],
        ["Low-risk vehicles", int(risk_counts.get("Low", 0)), "Normal monitoring list"],
        ["Average predicted risk", predictions["service_risk_probability"].mean(), "Mean probability across test vehicles"],
        ["Model recall", recall, "Coverage of true service-required cases"],
        ["Model ROC-AUC", roc_auc, "Risk-ranking quality"],
    ],
    columns=["kpi", "value", "business_interpretation"],
)
kpis.to_csv(BASE_DIR / "predictive_analytics_kpi_summary.csv", index=False)

print("Predictive analytics workflow completed successfully.")
print(f"Source records : {len(data)}")
print(f"Training rows  : {len(X_train)}")
print(f"Testing rows   : {len(X_test)}")
print(f"Accuracy       : {accuracy:.3f}")
print(f"Precision      : {precision:.3f}")
print(f"Recall         : {recall:.3f}")
print(f"F1 Score       : {f1:.3f}")
print(f"ROC-AUC        : {roc_auc:.3f}")
print(f"Confusion matrix: TN={tn}, FP={fp}, FN={fn}, TP={tp}")
print(f"Reports saved in: {BASE_DIR}")

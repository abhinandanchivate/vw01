PREDICTIVE ANALYTICS - COMPLETE CASE STUDY

Scenario: Predict whether a vehicle will require service in the next 30 days.

Key files:
- vehicle_predictive_maintenance_sample.csv: 2,000-row sample dataset
- vehicle_risk_predictions.csv: probability, risk band and action
- predictive_analytics_kpi_summary.csv: management KPIs
- model_performance_metrics.csv: model performance
- feature_importance.csv: feature importance
- data_dictionary.csv: data dictionary
- predictive_maintenance_case_study.py: complete Python code
- Predictive_Analytics_Workflow_Architecture.png: workflow architecture
- Predictive_Analytics_Vehicle_Service_Risk_Case_Study.docx: editable case-study document

Run code:
1. pip install pandas numpy scikit-learn
2. Keep the Python file and source CSV together.
3. python predictive_maintenance_case_study.py

Risk bands:
- Low: below 30%
- Medium: 30%-60%
- High: above 60%

This is synthetic training data and not a production maintenance model.

# Start Here - Missing Values, Outliers, and Data Balancing Package

## Recommended order

1. `01_Documentation/ML_Data_Quality_and_Balancing_Case_Study.pdf` - complete concept and case-study report.
2. `02_Data/data_dictionary.csv` - understand every field.
3. `02_Data/vehicle_service_risk_raw.csv` - inspect the intentionally imperfect raw data.
4. `04_Notebook/missing_values_outliers_balancing_case_study.ipynb` - run the guided lab cell by cell.
5. `03_Source_Code/data_preprocessing_balancing.py` - production-style end-to-end implementation.
6. `05_Outputs/model_comparison.csv` and `05_Outputs/plots/` - review the results.
7. `03_Source_Code/reusable_imbalanced_pipeline.py` - leakage-safe cross-validation pattern.
8. `07_Assessment/` - exercises, interview questions, and answers.

## Fast execution

### Windows

```bat
cd 03_Source_Code
run_all_windows.bat
```

### macOS/Linux

```bash
cd 03_Source_Code
./run_all.sh
```

## What the demonstration proves

- The dataset has 3,000 rows, intentionally introduced missing values, several extreme values, and about 10% High Risk records.
- Missing-value, outlier, encoding, and scaling parameters are learned only from training data.
- The validation/test set is not balanced.
- Accuracy alone hides minority-class failures.
- SMOTE, undersampling, and class weighting must be compared rather than selected automatically.

"""Load the saved model bundle and score a new vehicle."""
from pathlib import Path

import joblib
import pandas as pd

MODEL_FILE = Path(__file__).resolve().parents[1] / "05_Outputs" / "model" / "service_risk_model_bundle.joblib"


def main() -> None:
    bundle = joblib.load(MODEL_FILE)
    sample = pd.DataFrame([
        {
            "mileage_km": 72000,
            "service_gap_months": 14,
            "engine_alerts": 5,
            "brake_wear_percent": 82,
            "warranty_claims": 2,
            "customer_complaints": 3,
            "vehicle_age_years": 6.5,
            "avg_monthly_km": 1700,
            "battery_voltage": "Low",
            "driving_pattern": "City",
            "fuel_type": "Diesel",
        }
    ])

    # Apply the same training-derived outlier caps.
    for column, limit in bundle["iqr_limits"].items():
        sample[column] = sample[column].clip(limit["lower"], limit["upper"])

    X = bundle["preprocessor"].transform(sample[bundle["features"]])
    probability = float(bundle["model"].predict_proba(X)[0, 1])
    prediction = "High Risk" if probability >= 0.5 else "Low Risk"

    print(f"Selected training method: {bundle['selected_method']}")
    print(f"Prediction: {prediction}")
    print(f"High-risk probability: {probability:.2%}")


if __name__ == "__main__":
    main()

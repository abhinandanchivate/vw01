#!/usr/bin/env bash
set -euo pipefail
python -m pip install -r requirements.txt
python data_preprocessing_balancing.py
python reusable_imbalanced_pipeline.py
python predict_new_vehicle.py

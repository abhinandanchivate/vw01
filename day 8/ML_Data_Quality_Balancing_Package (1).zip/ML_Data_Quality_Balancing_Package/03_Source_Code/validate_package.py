"""Validate the generated package and key modelling safeguards."""
from pathlib import Path
import json

import joblib
import nbformat
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]


def check(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)
    print(f"PASS: {message}")


def main() -> None:
    raw = pd.read_csv(ROOT / "02_Data" / "vehicle_service_risk_raw.csv")
    cleaned = pd.read_csv(ROOT / "05_Outputs" / "vehicle_service_risk_cleaned.csv")
    smote = pd.read_csv(ROOT / "05_Outputs" / "training_balanced_smote.csv")
    under = pd.read_csv(ROOT / "05_Outputs" / "training_balanced_undersampling.csv")
    comparison = pd.read_csv(ROOT / "05_Outputs" / "model_comparison.csv")
    predictions = pd.read_csv(ROOT / "05_Outputs" / "sample_predictions_top_100.csv")

    check(len(raw) == 3000, "raw dataset contains 3,000 rows")
    check(raw.isna().sum().sum() > 0, "raw dataset intentionally contains missing values")
    check(cleaned.isna().sum().sum() == 0, "cleaned dataset contains no missing values")
    check(
        smote["service_risk"].value_counts().nunique() == 1,
        "SMOTE training output has equal class counts",
    )
    check(
        under["service_risk"].value_counts().nunique() == 1,
        "undersampled training output has equal class counts",
    )
    check(len(comparison) == 4, "four modelling strategies were compared")
    check(len(predictions) == 100, "top 100 held-out predictions were saved")
    check(
        comparison.iloc[0]["method"] == "SMOTE",
        "model comparison is sorted by the configured minority-focused selection rule",
    )

    bundle_path = ROOT / "05_Outputs" / "model" / "service_risk_model_bundle.joblib"
    bundle = joblib.load(bundle_path)
    check(bundle["selected_method"] == "SMOTE", "saved bundle records selected method")
    check("preprocessor" in bundle and "model" in bundle, "saved bundle contains preprocessor and model")

    notebook_path = ROOT / "04_Notebook" / "missing_values_outliers_balancing_case_study.ipynb"
    notebook = nbformat.read(notebook_path, as_version=4)
    errors = []
    for cell in notebook.cells:
        if cell.cell_type == "code":
            for output in cell.get("outputs", []):
                if output.get("output_type") == "error":
                    errors.append(output.get("ename", "UnknownError"))
    check(not errors, "executed notebook contains no error outputs")

    required = [
        ROOT / "01_Documentation" / "ML_Data_Quality_and_Balancing_Case_Study.docx",
        ROOT / "01_Documentation" / "ML_Data_Quality_and_Balancing_Case_Study.pdf",
        ROOT / "08_Excel" / "ML_Data_Quality_Balancing_Report.xlsx",
        ROOT / "06_Workflow" / "ml_data_quality_workflow.png",
    ]
    for path in required:
        check(path.exists() and path.stat().st_size > 0, f"required artifact exists: {path.name}")

    with (ROOT / "05_Outputs" / "metrics.json").open(encoding="utf-8") as f:
        metrics = json.load(f)
    check(len(metrics["results"]) == 4, "metrics JSON contains all four approaches")

    print("\nAll package validation checks passed.")


if __name__ == "__main__":
    main()

"""End-to-end case study: missing values, outliers, and imbalanced classes.

Key safeguards
--------------
1. Split into train/test before learning medians, modes, outlier limits, encoders, or scalers.
2. Apply SMOTE/undersampling to the training set only.
3. Keep the test set untouched by balancing so evaluation reflects production reality.

Run:
    python data_preprocessing_balancing.py

The script generates the synthetic raw dataset when it does not already exist,
then creates cleaned data, balancing outputs, plots, reports, and a saved model.
"""
from __future__ import annotations

import json
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import joblib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from imblearn.over_sampling import SMOTE
from imblearn.under_sampling import RandomUnderSampler
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    average_precision_score,
    balanced_accuracy_score,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
)
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

RANDOM_STATE = 42
TARGET = "service_risk"
ID_COLUMN = "vehicle_id"

SCRIPT_DIR = Path(__file__).resolve().parent
PACKAGE_ROOT = SCRIPT_DIR.parent
DATA_DIR = PACKAGE_ROOT / "02_Data"
OUTPUT_DIR = PACKAGE_ROOT / "05_Outputs"
PLOT_DIR = OUTPUT_DIR / "plots"
MODEL_DIR = OUTPUT_DIR / "model"
RAW_FILE = DATA_DIR / "vehicle_service_risk_raw.csv"

NUMERIC_FEATURES = [
    "mileage_km",
    "service_gap_months",
    "engine_alerts",
    "brake_wear_percent",
    "warranty_claims",
    "customer_complaints",
    "vehicle_age_years",
    "avg_monthly_km",
]
CATEGORICAL_FEATURES = ["battery_voltage", "driving_pattern", "fuel_type"]
FEATURES = NUMERIC_FEATURES + CATEGORICAL_FEATURES


@dataclass
class IQRLimits:
    lower: float
    upper: float
    q1: float
    q3: float
    iqr: float


def sigmoid(x: np.ndarray) -> np.ndarray:
    return 1.0 / (1.0 + np.exp(-x))


def generate_dataset(n_rows: int = 3000, seed: int = RANDOM_STATE) -> pd.DataFrame:
    """Create a reproducible, realistic, intentionally imperfect dataset."""
    rng = np.random.default_rng(seed)

    vehicle_age = np.clip(rng.gamma(shape=2.2, scale=2.2, size=n_rows), 0.2, 18)
    avg_monthly_km = np.clip(rng.normal(1450, 600, n_rows), 150, 5000)
    mileage = np.clip(vehicle_age * 12 * avg_monthly_km + rng.normal(0, 9000, n_rows), 1000, 260000)
    service_gap = np.clip(rng.gamma(shape=2.0, scale=3.8, size=n_rows), 0.5, 30)
    engine_alerts = np.clip(rng.poisson(1.2 + mileage / 100000), 0, 12)
    brake_wear = np.clip(18 + mileage / 2300 + service_gap * 1.3 + rng.normal(0, 10, n_rows), 3, 100)
    warranty_claims = np.clip(rng.poisson(0.25 + vehicle_age / 12), 0, 7)
    complaints = np.clip(rng.poisson(0.3 + service_gap / 20 + engine_alerts / 8), 0, 8)

    driving_pattern = rng.choice(["City", "Highway", "Mixed"], size=n_rows, p=[0.47, 0.25, 0.28])
    fuel_type = rng.choice(["Petrol", "Diesel", "CNG", "Electric"], size=n_rows, p=[0.43, 0.34, 0.11, 0.12])

    low_battery_probability = np.clip(
        0.08 + 0.018 * vehicle_age + 0.02 * service_gap + 0.04 * complaints, 0.05, 0.82
    )
    battery_voltage = np.where(rng.random(n_rows) < low_battery_probability, "Low", "Normal")

    risk_score = (
        -10.0
        + 0.000018 * mileage
        + 0.13 * service_gap
        + 0.39 * engine_alerts
        + 0.025 * brake_wear
        + 0.42 * complaints
        + 0.18 * warranty_claims
        + 0.9 * (battery_voltage == "Low")
        + 0.3 * (driving_pattern == "City")
        + 0.2 * (fuel_type == "Diesel")
        + rng.normal(0, 0.65, n_rows)
    )
    probabilities = sigmoid(risk_score)
    target = np.where(rng.random(n_rows) < probabilities, "High Risk", "Low Risk")

    df = pd.DataFrame(
        {
            ID_COLUMN: [f"VH-{i:05d}" for i in range(1, n_rows + 1)],
            "mileage_km": np.round(mileage).astype(int),
            "service_gap_months": np.round(service_gap, 1),
            "engine_alerts": engine_alerts.astype(int),
            "brake_wear_percent": np.round(brake_wear, 1),
            "battery_voltage": battery_voltage,
            "warranty_claims": warranty_claims.astype(int),
            "customer_complaints": complaints.astype(int),
            "driving_pattern": driving_pattern,
            "fuel_type": fuel_type,
            "vehicle_age_years": np.round(vehicle_age, 1),
            "avg_monthly_km": np.round(avg_monthly_km).astype(int),
            TARGET: target,
        }
    )

    # Inject missing values into features only (roughly 3%-7% by selected column).
    missing_rates = {
        "mileage_km": 0.03,
        "service_gap_months": 0.06,
        "engine_alerts": 0.035,
        "brake_wear_percent": 0.07,
        "battery_voltage": 0.045,
        "customer_complaints": 0.04,
        "driving_pattern": 0.025,
        "fuel_type": 0.02,
        "avg_monthly_km": 0.035,
    }
    for column, rate in missing_rates.items():
        idx = rng.choice(df.index, size=max(1, int(n_rows * rate)), replace=False)
        df.loc[idx, column] = np.nan

    # Inject a small number of extreme/invalid values to demonstrate outlier handling.
    outlier_specs = {
        "mileage_km": (0.012, lambda size: rng.integers(310000, 650000, size=size)),
        "service_gap_months": (0.012, lambda size: rng.uniform(42, 90, size=size)),
        "engine_alerts": (0.010, lambda size: rng.integers(22, 55, size=size)),
        "brake_wear_percent": (0.012, lambda size: rng.uniform(125, 220, size=size)),
        "avg_monthly_km": (0.010, lambda size: rng.integers(9000, 22000, size=size)),
    }
    for column, (rate, generator) in outlier_specs.items():
        available = df.index[df[column].notna()]
        idx = rng.choice(available, size=max(1, int(n_rows * rate)), replace=False)
        df.loc[idx, column] = generator(len(idx))

    return df


def fit_iqr_limits(train_df: pd.DataFrame, columns: list[str], factor: float = 1.5) -> dict[str, IQRLimits]:
    limits: dict[str, IQRLimits] = {}
    for column in columns:
        values = pd.to_numeric(train_df[column], errors="coerce").dropna()
        q1 = float(values.quantile(0.25))
        q3 = float(values.quantile(0.75))
        iqr = q3 - q1
        limits[column] = IQRLimits(
            lower=q1 - factor * iqr,
            upper=q3 + factor * iqr,
            q1=q1,
            q3=q3,
            iqr=iqr,
        )
    return limits


def cap_outliers(df: pd.DataFrame, limits: dict[str, IQRLimits]) -> pd.DataFrame:
    result = df.copy()
    for column, lim in limits.items():
        result[column] = pd.to_numeric(result[column], errors="coerce").clip(lim.lower, lim.upper)
    return result


def build_preprocessor() -> ColumnTransformer:
    numeric_pipeline = Pipeline(
        steps=[
            ("imputer", SimpleImputer(strategy="median", add_indicator=True)),
            ("scaler", StandardScaler()),
        ]
    )
    categorical_pipeline = Pipeline(
        steps=[
            ("imputer", SimpleImputer(strategy="most_frequent")),
            ("onehot", OneHotEncoder(handle_unknown="ignore", sparse_output=False)),
        ]
    )
    return ColumnTransformer(
        transformers=[
            ("numeric", numeric_pipeline, NUMERIC_FEATURES),
            ("categorical", categorical_pipeline, CATEGORICAL_FEATURES),
        ],
        remainder="drop",
        verbose_feature_names_out=True,
    )


def metrics_for(name: str, model: LogisticRegression, X_test: np.ndarray, y_test: pd.Series,
                train_rows: int, train_positive: int, train_negative: int) -> dict[str, Any]:
    prediction = model.predict(X_test)
    probability = model.predict_proba(X_test)[:, 1]
    tn, fp, fn, tp = confusion_matrix(y_test, prediction, labels=[0, 1]).ravel()
    return {
        "method": name,
        "training_rows": int(train_rows),
        "train_low_risk": int(train_negative),
        "train_high_risk": int(train_positive),
        "accuracy": accuracy_score(y_test, prediction),
        "balanced_accuracy": balanced_accuracy_score(y_test, prediction),
        "precision_high_risk": precision_score(y_test, prediction, zero_division=0),
        "recall_high_risk": recall_score(y_test, prediction, zero_division=0),
        "f1_high_risk": f1_score(y_test, prediction, zero_division=0),
        "roc_auc": roc_auc_score(y_test, probability),
        "pr_auc": average_precision_score(y_test, probability),
        "true_negative": int(tn),
        "false_positive": int(fp),
        "false_negative": int(fn),
        "true_positive": int(tp),
    }


def save_plot(fig: plt.Figure, filename: str) -> None:
    fig.tight_layout()
    fig.savefig(PLOT_DIR / filename, dpi=170, bbox_inches="tight")
    plt.close(fig)


def main() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    PLOT_DIR.mkdir(parents=True, exist_ok=True)
    MODEL_DIR.mkdir(parents=True, exist_ok=True)

    if RAW_FILE.exists():
        raw = pd.read_csv(RAW_FILE)
    else:
        raw = generate_dataset()
        raw.to_csv(RAW_FILE, index=False)

    # Data dictionary
    dictionary = pd.DataFrame(
        [
            [ID_COLUMN, "Identifier", "Unique vehicle record ID", "VH-00001"],
            ["mileage_km", "Numeric", "Total vehicle mileage in kilometres", "72000"],
            ["service_gap_months", "Numeric", "Months since last service", "14"],
            ["engine_alerts", "Numeric", "Count of recent engine alerts", "5"],
            ["brake_wear_percent", "Numeric", "Estimated brake wear percentage", "82"],
            ["battery_voltage", "Categorical", "Battery condition", "Low / Normal"],
            ["warranty_claims", "Numeric", "Previous warranty claims", "2"],
            ["customer_complaints", "Numeric", "Recent customer complaints", "3"],
            ["driving_pattern", "Categorical", "Primary usage pattern", "City / Highway / Mixed"],
            ["fuel_type", "Categorical", "Vehicle fuel or powertrain", "Petrol / Diesel / CNG / Electric"],
            ["vehicle_age_years", "Numeric", "Age of vehicle in years", "6.5"],
            ["avg_monthly_km", "Numeric", "Average kilometres driven per month", "1600"],
            [TARGET, "Target", "Actual service risk within 30 days", "High Risk / Low Risk"],
        ],
        columns=["column", "type", "description", "example"],
    )
    dictionary.to_csv(DATA_DIR / "data_dictionary.csv", index=False)

    X = raw[FEATURES].copy()
    y = raw[TARGET].map({"Low Risk": 0, "High Risk": 1})

    X_train, X_test, y_train, y_test = train_test_split(
        X,
        y,
        test_size=0.25,
        stratify=y,
        random_state=RANDOM_STATE,
    )

    # Learn outlier boundaries from training data only.
    iqr_limits = fit_iqr_limits(X_train, NUMERIC_FEATURES)
    X_train_capped = cap_outliers(X_train, iqr_limits)
    X_test_capped = cap_outliers(X_test, iqr_limits)

    preprocessor = build_preprocessor()
    X_train_processed = preprocessor.fit_transform(X_train_capped)
    X_test_processed = preprocessor.transform(X_test_capped)
    feature_names = list(preprocessor.get_feature_names_out())

    strategies: dict[str, tuple[np.ndarray, np.ndarray]] = {
        "Baseline - Imbalanced": (X_train_processed, y_train.to_numpy()),
    }

    smote = SMOTE(random_state=RANDOM_STATE, k_neighbors=5)
    X_smote, y_smote = smote.fit_resample(X_train_processed, y_train)
    strategies["SMOTE"] = (X_smote, y_smote)

    undersampler = RandomUnderSampler(random_state=RANDOM_STATE)
    X_under, y_under = undersampler.fit_resample(X_train_processed, y_train)
    strategies["Random Undersampling"] = (X_under, y_under)

    # Class weighting is included as a useful non-resampling comparison.
    models: dict[str, LogisticRegression] = {}
    results: list[dict[str, Any]] = []

    for name, (X_fit, y_fit) in strategies.items():
        model = LogisticRegression(max_iter=2000, random_state=RANDOM_STATE)
        model.fit(X_fit, y_fit)
        models[name] = model
        results.append(
            metrics_for(
                name,
                model,
                X_test_processed,
                y_test,
                train_rows=len(y_fit),
                train_positive=int(np.sum(y_fit == 1)),
                train_negative=int(np.sum(y_fit == 0)),
            )
        )

    weighted_model = LogisticRegression(
        max_iter=2000,
        class_weight="balanced",
        random_state=RANDOM_STATE,
    )
    weighted_model.fit(X_train_processed, y_train)
    models["Class Weight Balanced"] = weighted_model
    results.append(
        metrics_for(
            "Class Weight Balanced",
            weighted_model,
            X_test_processed,
            y_test,
            train_rows=len(y_train),
            train_positive=int((y_train == 1).sum()),
            train_negative=int((y_train == 0).sum()),
        )
    )

    results_df = pd.DataFrame(results).sort_values(
        ["f1_high_risk", "recall_high_risk", "pr_auc"], ascending=False
    )
    results_df.to_csv(OUTPUT_DIR / "model_comparison.csv", index=False)

    # Choose by minority-class F1, then recall and PR-AUC.
    best_method = str(results_df.iloc[0]["method"])
    best_model = models[best_method]

    # Reports: missing values, outlier counts, and distributions.
    missing_report = pd.DataFrame(
        {
            "column": raw.columns,
            "missing_count": [int(raw[c].isna().sum()) for c in raw.columns],
            "missing_percent": [round(float(raw[c].isna().mean() * 100), 2) for c in raw.columns],
        }
    ).sort_values("missing_percent", ascending=False)
    missing_report.to_csv(OUTPUT_DIR / "missing_values_report.csv", index=False)

    outlier_rows = []
    for column, lim in iqr_limits.items():
        values = pd.to_numeric(raw[column], errors="coerce")
        before_count = int(((values < lim.lower) | (values > lim.upper)).sum())
        capped_values = values.clip(lim.lower, lim.upper)
        after_count = int(((capped_values < lim.lower) | (capped_values > lim.upper)).sum())
        outlier_rows.append(
            {
                "column": column,
                "q1_train": lim.q1,
                "q3_train": lim.q3,
                "iqr_train": lim.iqr,
                "lower_limit": lim.lower,
                "upper_limit": lim.upper,
                "outliers_before_capping": before_count,
                "outliers_after_capping": after_count,
            }
        )
    outlier_report = pd.DataFrame(outlier_rows)
    outlier_report.to_csv(OUTPUT_DIR / "outlier_summary.csv", index=False)

    distribution_rows = []
    for method, (_, labels) in strategies.items():
        labels_array = np.asarray(labels)
        distribution_rows.append(
            {
                "dataset": method,
                "low_risk_count": int(np.sum(labels_array == 0)),
                "high_risk_count": int(np.sum(labels_array == 1)),
                "high_risk_percent": round(float(np.mean(labels_array == 1) * 100), 2),
            }
        )
    distribution_rows.append(
        {
            "dataset": "Original Full Dataset",
            "low_risk_count": int((y == 0).sum()),
            "high_risk_count": int((y == 1).sum()),
            "high_risk_percent": round(float(y.mean() * 100), 2),
        }
    )
    distribution_df = pd.DataFrame(distribution_rows)
    distribution_df.to_csv(OUTPUT_DIR / "class_distribution_report.csv", index=False)

    # Save processed and balanced datasets with feature names.
    train_processed_df = pd.DataFrame(X_train_processed, columns=feature_names)
    train_processed_df[TARGET] = y_train.reset_index(drop=True)
    train_processed_df.to_csv(OUTPUT_DIR / "training_processed_imbalanced.csv", index=False)

    smote_df = pd.DataFrame(X_smote, columns=feature_names)
    smote_df[TARGET] = y_smote
    smote_df.to_csv(OUTPUT_DIR / "training_balanced_smote.csv", index=False)

    under_df = pd.DataFrame(X_under, columns=feature_names)
    under_df[TARGET] = y_under
    under_df.to_csv(OUTPUT_DIR / "training_balanced_undersampling.csv", index=False)

    # Create a human-readable cleaned full dataset using train-derived caps and imputations.
    full_capped = cap_outliers(raw[FEATURES], iqr_limits)
    cleaned = raw[[ID_COLUMN, TARGET]].copy()
    numeric_medians = X_train_capped[NUMERIC_FEATURES].median(numeric_only=True)
    categorical_modes = {
        c: X_train_capped[c].mode(dropna=True).iloc[0] for c in CATEGORICAL_FEATURES
    }
    for c in NUMERIC_FEATURES:
        cleaned[c] = full_capped[c].fillna(numeric_medians[c])
    for c in CATEGORICAL_FEATURES:
        cleaned[c] = full_capped[c].fillna(categorical_modes[c])
    cleaned = cleaned[[ID_COLUMN] + FEATURES + [TARGET]]
    cleaned.to_csv(OUTPUT_DIR / "vehicle_service_risk_cleaned.csv", index=False)

    # Predictions for held-out test records.
    probabilities = best_model.predict_proba(X_test_processed)[:, 1]
    predictions = best_model.predict(X_test_processed)
    prediction_df = raw.loc[X_test.index, [ID_COLUMN] + FEATURES + [TARGET]].copy()
    prediction_df["actual_encoded"] = y_test
    prediction_df["predicted_risk"] = np.where(predictions == 1, "High Risk", "Low Risk")
    prediction_df["high_risk_probability"] = np.round(probabilities, 4)
    prediction_df.sort_values("high_risk_probability", ascending=False).head(100).to_csv(
        OUTPUT_DIR / "sample_predictions_top_100.csv", index=False
    )

    # Data quality summary.
    quality_summary = pd.DataFrame(
        [
            ["Rows - raw", len(raw)],
            ["Columns - raw", raw.shape[1]],
            ["Total missing cells - raw", int(raw.isna().sum().sum())],
            ["Rows - training", len(X_train)],
            ["Rows - test", len(X_test)],
            ["Minority rate - full dataset (%)", round(float(y.mean() * 100), 2)],
            ["Best balancing method by F1", best_method],
            ["Best minority F1", round(float(results_df.iloc[0]["f1_high_risk"]), 4)],
            ["Best minority recall", round(float(results_df.iloc[0]["recall_high_risk"]), 4)],
            ["Best PR-AUC", round(float(results_df.iloc[0]["pr_auc"]), 4)],
        ],
        columns=["metric", "value"],
    )
    quality_summary.to_csv(OUTPUT_DIR / "data_quality_summary.csv", index=False)

    # Save metadata and trained model bundle.
    bundle = {
        "preprocessor": preprocessor,
        "model": best_model,
        "iqr_limits": {c: {"lower": v.lower, "upper": v.upper, "q1": v.q1, "q3": v.q3, "iqr": v.iqr} for c, v in iqr_limits.items()},
        "features": FEATURES,
        "numeric_features": NUMERIC_FEATURES,
        "categorical_features": CATEGORICAL_FEATURES,
        "target_mapping": {"Low Risk": 0, "High Risk": 1},
        "selected_method": best_method,
    }
    joblib.dump(bundle, MODEL_DIR / "service_risk_model_bundle.joblib")

    metrics_payload = {
        "random_state": RANDOM_STATE,
        "selected_method": best_method,
        "selection_rule": "Highest minority-class F1; tie-breakers recall then PR-AUC",
        "results": results_df.to_dict(orient="records"),
    }
    with (OUTPUT_DIR / "metrics.json").open("w", encoding="utf-8") as f:
        json.dump(metrics_payload, f, indent=2)

    # Plots
    plot_missing = missing_report[missing_report["missing_count"] > 0].sort_values("missing_percent")
    fig, ax = plt.subplots(figsize=(9, 5))
    ax.barh(plot_missing["column"], plot_missing["missing_percent"])
    ax.set_title("Missing Values by Feature")
    ax.set_xlabel("Missing values (%)")
    save_plot(fig, "01_missing_values.png")

    fig, ax = plt.subplots(figsize=(8, 5))
    original_counts = raw[TARGET].value_counts().reindex(["Low Risk", "High Risk"])
    ax.bar(original_counts.index, original_counts.values)
    ax.set_title("Original Class Distribution")
    ax.set_ylabel("Records")
    for i, value in enumerate(original_counts.values):
        ax.text(i, value, str(int(value)), ha="center", va="bottom")
    save_plot(fig, "02_original_class_distribution.png")

    balance_plot = distribution_df[distribution_df["dataset"].isin(["Baseline - Imbalanced", "SMOTE", "Random Undersampling"])]
    x = np.arange(len(balance_plot))
    width = 0.36
    fig, ax = plt.subplots(figsize=(10, 5))
    ax.bar(x - width / 2, balance_plot["low_risk_count"], width, label="Low Risk")
    ax.bar(x + width / 2, balance_plot["high_risk_count"], width, label="High Risk")
    ax.set_xticks(x)
    ax.set_xticklabels(balance_plot["dataset"], rotation=12, ha="right")
    ax.set_title("Training Class Balance Before and After Resampling")
    ax.set_ylabel("Training records")
    ax.legend()
    save_plot(fig, "03_balancing_comparison.png")

    # Boxplot before/after for selected outlier-prone columns.
    selected = ["mileage_km", "service_gap_months", "brake_wear_percent", "avg_monthly_km"]
    fig, ax = plt.subplots(figsize=(10, 5))
    ax.boxplot([pd.to_numeric(raw[c], errors="coerce").dropna() for c in selected], tick_labels=selected)
    ax.set_title("Selected Numeric Features Before Outlier Capping")
    ax.tick_params(axis="x", rotation=18)
    save_plot(fig, "04_boxplots_before_capping.png")

    fig, ax = plt.subplots(figsize=(10, 5))
    capped_full = cap_outliers(raw[selected], {c: iqr_limits[c] for c in selected})
    ax.boxplot([capped_full[c].dropna() for c in selected], tick_labels=selected)
    ax.set_title("Selected Numeric Features After Train-Derived IQR Capping")
    ax.tick_params(axis="x", rotation=18)
    save_plot(fig, "05_boxplots_after_capping.png")

    metric_plot = results_df.set_index("method")[["precision_high_risk", "recall_high_risk", "f1_high_risk", "pr_auc"]]
    fig, ax = plt.subplots(figsize=(11, 6))
    metric_plot.plot(kind="bar", ax=ax)
    ax.set_title("Minority-Class Model Performance")
    ax.set_ylabel("Score")
    ax.set_ylim(0, 1)
    ax.tick_params(axis="x", rotation=18)
    ax.legend(loc="lower right")
    save_plot(fig, "06_model_comparison.png")

    # Confusion matrix for best model.
    best_pred = best_model.predict(X_test_processed)
    cm = confusion_matrix(y_test, best_pred, labels=[0, 1])
    fig, ax = plt.subplots(figsize=(6, 5))
    image = ax.imshow(cm)
    fig.colorbar(image, ax=ax)
    ax.set_xticks([0, 1], labels=["Low Risk", "High Risk"])
    ax.set_yticks([0, 1], labels=["Low Risk", "High Risk"])
    ax.set_xlabel("Predicted")
    ax.set_ylabel("Actual")
    ax.set_title(f"Confusion Matrix - {best_method}")
    for i in range(2):
        for j in range(2):
            ax.text(j, i, int(cm[i, j]), ha="center", va="center")
    save_plot(fig, "07_best_model_confusion_matrix.png")

    print("Processing completed successfully.")
    print(f"Raw dataset: {RAW_FILE}")
    print(f"Best method: {best_method}")
    print(results_df.to_string(index=False))


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise

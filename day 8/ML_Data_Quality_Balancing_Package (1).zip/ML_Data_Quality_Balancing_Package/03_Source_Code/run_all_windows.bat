@echo off
python -m pip install -r requirements.txt
if errorlevel 1 exit /b 1
python data_preprocessing_balancing.py
if errorlevel 1 exit /b 1
python reusable_imbalanced_pipeline.py
if errorlevel 1 exit /b 1
python predict_new_vehicle.py

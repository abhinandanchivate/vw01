# Source Code Guide

## `data_preprocessing_balancing.py`

The main end-to-end program. It:

1. generates or reads the 3,000-row raw dataset;
2. writes the data dictionary;
3. performs a stratified train-test split;
4. learns IQR limits from training data;
5. caps train and test using those training-derived limits;
6. fits median/mode imputation, missing indicators, encoding, and scaling;
7. compares no balancing, SMOTE, undersampling, and class weighting;
8. writes cleaned/balanced datasets, reports, plots, and predictions;
9. saves the selected preprocessor/model bundle.

## `reusable_imbalanced_pipeline.py`

Demonstrates the recommended cross-validation design using `imblearn.pipeline.Pipeline`. The sampler runs only in each training fold.

## `predict_new_vehicle.py`

Loads the saved model bundle, applies the original outlier limits and preprocessing, and predicts one new vehicle.

## `validate_package.py`

Checks row counts, missing-value cleanup, class balance, output files, saved model loading, and notebook execution errors.

## Run

```bash
python -m pip install -r requirements.txt
python data_preprocessing_balancing.py
python reusable_imbalanced_pipeline.py
python predict_new_vehicle.py
python validate_package.py
```

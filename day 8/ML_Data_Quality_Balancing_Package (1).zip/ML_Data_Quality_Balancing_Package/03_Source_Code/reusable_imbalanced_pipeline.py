"""Reusable leakage-safe imbalanced-learn pipeline example.

Use this pattern when cross-validation or hyperparameter tuning is required.
The sampler is inside imblearn.pipeline.Pipeline, so it is applied only to the
training fold during each CV iteration.
"""
from pathlib import Path

import pandas as pd
from imblearn.over_sampling import SMOTE
from imblearn.pipeline import Pipeline as ImbPipeline
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold, cross_validate
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

DATA_FILE = Path(__file__).resolve().parents[1] / "02_Data" / "vehicle_service_risk_raw.csv"
TARGET = "service_risk"
NUMERIC = [
    "mileage_km", "service_gap_months", "engine_alerts", "brake_wear_percent",
    "warranty_claims", "customer_complaints", "vehicle_age_years", "avg_monthly_km",
]
CATEGORICAL = ["battery_voltage", "driving_pattern", "fuel_type"]


def build_pipeline() -> ImbPipeline:
    numeric = Pipeline([
        ("imputer", SimpleImputer(strategy="median", add_indicator=True)),
        ("scaler", StandardScaler()),
    ])
    categorical = Pipeline([
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("encoder", OneHotEncoder(handle_unknown="ignore")),
    ])
    preprocessing = ColumnTransformer([
        ("numeric", numeric, NUMERIC),
        ("categorical", categorical, CATEGORICAL),
    ])

    return ImbPipeline([
        ("preprocessing", preprocessing),
        ("smote", SMOTE(random_state=42)),
        ("model", LogisticRegression(max_iter=2000, random_state=42)),
    ])


def main() -> None:
    data = pd.read_csv(DATA_FILE)
    X = data[NUMERIC + CATEGORICAL]
    y = data[TARGET].map({"Low Risk": 0, "High Risk": 1})

    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    scores = cross_validate(
        build_pipeline(),
        X,
        y,
        cv=cv,
        scoring={
            "roc_auc": "roc_auc",
            "average_precision": "average_precision",
            "f1": "f1",
            "recall": "recall",
            "balanced_accuracy": "balanced_accuracy",
        },
        n_jobs=1,
    )

    for metric, values in scores.items():
        if metric.startswith("test_"):
            print(f"{metric[5:]}: {values.mean():.4f} +/- {values.std():.4f}")


if __name__ == "__main__":
    main()

# Package Manifest

Total files: **49**

| File | Size |
|---|---:|
| `00_START_HERE.md` | 1.4 KB |
| `01_Documentation/Concepts_5W1H.md` | 2.4 KB |
| `01_Documentation/ML_Data_Quality_and_Balancing_Case_Study.docx` | 429.3 KB |
| `01_Documentation/ML_Data_Quality_and_Balancing_Case_Study.pdf` | 815.2 KB |
| `01_Documentation/Practical_Production_Checklist.md` | 1.9 KB |
| `01_Documentation/Quick_Reference_Cheat_Sheet.md` | 4.3 KB |
| `01_Documentation/Trainer_Guide.md` | 2.1 KB |
| `02_Data/data_dictionary.csv` | 837 B |
| `02_Data/vehicle_service_risk_raw.csv` | 217.5 KB |
| `03_Source_Code/README.md` | 1.2 KB |
| `03_Source_Code/data_preprocessing_balancing.py` | 22.8 KB |
| `03_Source_Code/predict_new_vehicle.py` | 1.3 KB |
| `03_Source_Code/requirements.txt` | 106 B |
| `03_Source_Code/reusable_imbalanced_pipeline.py` | 2.4 KB |
| `03_Source_Code/run_all.sh` | 188 B |
| `03_Source_Code/run_all_windows.bat` | 238 B |
| `03_Source_Code/validate_package.py` | 3.1 KB |
| `04_Notebook/missing_values_outliers_balancing_case_study.ipynb` | 138.2 KB |
| `05_Outputs/FINAL_RESULTS_SUMMARY.md` | 1.3 KB |
| `05_Outputs/Final_Analysis_Report.pdf` | 815.2 KB |
| `05_Outputs/class_distribution_report.csv` | 186 B |
| `05_Outputs/data_quality_summary.csv` | 258 B |
| `05_Outputs/metrics.json` | 2.2 KB |
| `05_Outputs/missing_values_report.csv` | 328 B |
| `05_Outputs/model/service_risk_model_bundle.joblib` | 6.4 KB |
| `05_Outputs/model_comparison.csv` | 883 B |
| `05_Outputs/outlier_summary.csv` | 604 B |
| `05_Outputs/plots/01_missing_values.png` | 58.3 KB |
| `05_Outputs/plots/02_original_class_distribution.png` | 30.9 KB |
| `05_Outputs/plots/03_balancing_comparison.png` | 66.9 KB |
| `05_Outputs/plots/04_boxplots_before_capping.png` | 74.7 KB |
| `05_Outputs/plots/05_boxplots_after_capping.png` | 64.3 KB |
| `05_Outputs/plots/06_model_comparison.png` | 82.6 KB |
| `05_Outputs/plots/07_best_model_confusion_matrix.png` | 34.7 KB |
| `05_Outputs/sample_predictions_top_100.csv` | 9.6 KB |
| `05_Outputs/training_balanced_smote.csv` | 1.29 MB |
| `05_Outputs/training_balanced_undersampling.csv` | 143.6 KB |
| `05_Outputs/training_processed_imbalanced.csv` | 703.2 KB |
| `05_Outputs/vehicle_service_risk_cleaned.csv` | 227.7 KB |
| `06_Workflow/ml_data_quality_workflow.dot` | 1.3 KB |
| `06_Workflow/ml_data_quality_workflow.mmd` | 902 B |
| `06_Workflow/ml_data_quality_workflow.png` | 52.6 KB |
| `06_Workflow/ml_data_quality_workflow.svg` | 12.8 KB |
| `07_Assessment/Hands_On_Assignment.md` | 1.6 KB |
| `07_Assessment/Interview_Questions_and_Answers.md` | 2.1 KB |
| `07_Assessment/MCQ_with_Answers.md` | 4.2 KB |
| `08_Excel/ML_Data_Quality_Balancing_Report.xlsx` | 37.8 KB |
| `08_Excel/dashboard_preview.png` | 137.0 KB |
| `README.md` | 1.6 KB |

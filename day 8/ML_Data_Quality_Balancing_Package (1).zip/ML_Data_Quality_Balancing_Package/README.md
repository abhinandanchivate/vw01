# ML Data Quality and Imbalanced Classification Training Package

A complete Python training package for handling missing values, outliers, and imbalanced target classes.

## Package contents

| Folder | Purpose |
|---|---|
| `01_Documentation` | Detailed case study, trainer guide, quick reference, DOCX and PDF report |
| `02_Data` | Raw synthetic automobile dataset and data dictionary |
| `03_Source_Code` | End-to-end script, reusable CV pipeline, prediction script, requirements |
| `04_Notebook` | Executed Jupyter notebook with explanations and outputs |
| `05_Outputs` | Cleaned/balanced datasets, model reports, plots, and serialized model |
| `06_Workflow` | Architecture/process flow in Mermaid, DOT, PNG, and SVG formats |
| `07_Assessment` | Hands-on assignment, MCQs, interview questions, and answer key |
| `08_Excel` | Consolidated Excel report with key tables and dashboard |

## Case study

A vehicle-service organization predicts whether a vehicle will require urgent service in the next 30 days. The raw data contains realistic quality problems:

- numeric and categorical missing values;
- implausible/extreme mileage, service-gap, alert, brake-wear, and monthly-usage values;
- only about 10% High Risk cases.

The package demonstrates median/mode imputation, missing indicators, train-derived IQR capping, one-hot encoding, scaling, SMOTE, random undersampling, class weighting, and appropriate evaluation metrics.

## Important safety rules for ML preprocessing

1. Split first.
2. Learn preprocessing only from training data.
3. Balance only training data.
4. Keep the test distribution realistic.
5. Evaluate the minority class directly.

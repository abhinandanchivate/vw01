# Missing Values, Outliers, and Data Balancing - 5W1H

## Handling missing values

| Question | Explanation |
|---|---|
| What? | Missing-value handling identifies absent values and either removes, imputes, models, or flags them. |
| Why? | Most ML algorithms cannot train reliably with missing values, and careless handling can bias the model. |
| Who? | Data analysts, data scientists, ML engineers, domain experts, and data owners. |
| When? | After initial data profiling and before final model training; learned rules must be fitted on training data only. |
| Where? | Sensor feeds, forms, healthcare records, finance, customer systems, manufacturing, and almost every real dataset. |
| How? | Diagnose the missingness mechanism, quantify it, choose deletion or imputation, add indicators where useful, validate distributions, and monitor in production. |

## Handling outliers

| Question | Explanation |
|---|---|
| What? | Outliers are observations far from typical values or outside valid business limits. |
| Why? | They may distort means, scaling, linear models, distance-based methods, and loss functions. They may also represent valuable rare events. |
| Who? | Data scientists and domain experts should decide together because statistical rarity is not the same as invalidity. |
| When? | During EDA and preprocessing, after checking data types and units, and before scaling or distance-based modelling. |
| Where? | Fraud, failures, sensor errors, financial transactions, medical readings, manufacturing defects, and demand spikes. |
| How? | Use domain rules, plots, IQR, z-scores, robust statistics, or anomaly models; then correct, remove, cap, transform, flag, or model separately. |

## Data balancing

| Question | Explanation |
|---|---|
| What? | Data balancing changes training data or training loss so the model learns minority cases better. |
| Why? | A model can obtain high accuracy by predicting only the majority class. |
| Who? | ML practitioners working on fraud, churn, disease, failure, defect, default, and risk prediction. |
| When? | After splitting and preprocessing design; resampling must occur only within training data or training folds. |
| Where? | Binary and multiclass classification where class frequencies or costs are uneven. |
| How? | Oversampling, SMOTE variants, undersampling, cleaning methods, class weights, threshold tuning, ensembles, or anomaly detection. |

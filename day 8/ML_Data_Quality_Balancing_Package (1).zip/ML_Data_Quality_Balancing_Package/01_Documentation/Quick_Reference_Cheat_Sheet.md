# Quick Reference Cheat Sheet

## Missing-value decision guide

| Situation | Usually consider | Caution |
|---|---|---|
| Less than ~1-2% missing and rows are plentiful | Row deletion | Verify missingness is not related to the target |
| Numeric, symmetric distribution | Mean imputation | Mean is sensitive to outliers |
| Numeric, skewed or outlier-prone | Median imputation | Can reduce variance and hide relationships |
| Categorical | Mode or explicit `Unknown` category | Mode can over-amplify the majority category |
| Time series | Forward/backward fill or interpolation | Never use future information for past predictions |
| Related features can predict the value | KNN, iterative, or model-based imputation | Fit only on training data; increases complexity |
| Missingness itself has meaning | Add a missing indicator | Do not assume indicators solve biased missingness |

### Missingness mechanisms

- **MCAR:** missingness is unrelated to observed or unobserved values.
- **MAR:** missingness depends on observed variables.
- **MNAR:** missingness depends on the missing value itself or an unobserved cause.

## Outlier decision guide

| Method | Best for | Core rule |
|---|---|---|
| Domain boundaries | Invalid values and known physical limits | Example: brake wear cannot reasonably exceed 100% |
| IQR | Skewed/univariate numeric variables | Outside Q1 - 1.5×IQR or Q3 + 1.5×IQR |
| Z-score | Approximately normal variables | Commonly absolute z-score > 3 |
| Modified z-score | Robust univariate detection | Uses median and MAD |
| Isolation Forest | Multivariate anomalies | Isolates unusual points using random trees |
| Local Outlier Factor | Local-density anomalies | Compares neighbourhood density |
| DBSCAN | Cluster/noise patterns | Labels low-density points as noise |

### Outlier actions

- Correct data-entry/unit errors.
- Remove only when demonstrably invalid or outside scope.
- Cap/winsorize to preserve rows.
- Log/Box-Cox/Yeo-Johnson transform skewed values.
- Use RobustScaler, tree models, Huber loss, or quantile loss.
- Add an outlier flag when rarity carries information.
- Build a separate anomaly model for rare-event detection.

## Imbalance technique guide

| Technique | Advantage | Limitation |
|---|---|---|
| Random oversampling | Simple; preserves minority examples | Duplicates can overfit |
| SMOTE | Creates synthetic minority examples | Can create ambiguous/noisy points |
| Borderline-SMOTE | Focuses near decision boundary | Sensitive to noisy boundaries |
| ADASYN | Generates more examples in difficult regions | May amplify noise |
| SMOTENC | Supports mixed numeric/categorical features | Requires correct categorical indices |
| Random undersampling | Fast; smaller training set | Discards majority information |
| Tomek Links | Cleans overlapping pairs | Usually not sufficient alone |
| Edited Nearest Neighbours | Removes noisy majority examples | Can remove useful data |
| SMOTEENN/SMOTETomek | Combines generation and cleaning | More computation and tuning |
| Class weights | Keeps all data; easy to use | Not supported equally by all algorithms |
| Threshold tuning | Aligns predictions with business cost | Needs a separate validation set |
| Balanced Random Forest | Ensemble designed for imbalance | More complex and less interpretable |

## Metrics for imbalanced classification

- Minority precision: of predicted positives, how many were correct?
- Minority recall/sensitivity: of real positives, how many were found?
- F1: harmonic balance of precision and recall.
- Specificity: of real negatives, how many were rejected correctly?
- Balanced accuracy: average of sensitivity and specificity.
- ROC-AUC: ranking quality across thresholds; may look optimistic under severe imbalance.
- PR-AUC: precision-recall trade-off; often more informative for rare positives.
- MCC: balanced correlation-style metric using all confusion-matrix cells.
- Cost-based score: explicitly applies business cost to false negatives and false positives.

## Non-negotiable leakage rules

1. Do not impute before train-test split.
2. Do not calculate IQR limits on the full dataset.
3. Do not scale before split.
4. Do not apply SMOTE before split.
5. Do not balance the validation/test set.
6. During cross-validation, use `imblearn.pipeline.Pipeline` so resampling occurs inside each training fold.

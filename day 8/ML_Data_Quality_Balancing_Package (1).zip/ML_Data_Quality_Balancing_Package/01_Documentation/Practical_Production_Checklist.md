# Production Checklist

## Data contract and profiling

- Confirm column types, units, allowed categories, physical limits, and target definition.
- Report missingness by time, source, geography, device, customer segment, and target.
- Check duplicate identifiers and contradictory records.
- Separate impossible values from extreme but plausible values.
- Version the data dictionary and preprocessing configuration.

## Train/validation/test design

- Use stratification for ordinary imbalanced classification.
- Use group-aware splitting when the same customer/device appears repeatedly.
- Use time-based splitting for future predictions.
- Keep a final untouched test set.
- Fit all transformations only on training data.

## Missing-value handling

- Preserve original raw fields for audit.
- Store learned medians/modes with the model.
- Add missingness indicators where the absence may be informative.
- Monitor imputation rates in production.
- Investigate drift when missing rates change.

## Outlier handling

- Store training-derived boundaries.
- Apply the same limits during inference.
- Log values that are capped.
- Monitor the percentage capped by feature.
- Revisit limits when data distribution or business policy changes.

## Imbalance handling

- Compare baseline, class weights, oversampling, undersampling, and threshold tuning.
- Use resampling inside CV folds.
- Avoid synthetic examples across time or entity boundaries.
- Check whether generated SMOTE points are physically plausible.
- Consider SMOTENC for mixed raw features.

## Evaluation and deployment

- Report class-specific precision, recall, F1, confusion matrix, PR-AUC, and ROC-AUC.
- Select the threshold from validation data using business costs.
- Check probability calibration if probabilities drive decisions.
- Test performance across important subgroups.
- Monitor target prevalence, feature drift, score drift, false-negative rate, and alert volume.

# Trainer Guide

## Suggested duration: 4 hours

| Time | Topic | Demonstration |
|---|---|---|
| 00:00-00:30 | Data-quality profiling | Missing counts, percentages, target distribution |
| 00:30-01:15 | Missing values | Mean vs median vs mode; missing indicators; leakage |
| 01:15-02:00 | Outliers | Domain rules, boxplots, IQR calculation, capping |
| 02:00-02:15 | Break | - |
| 02:15-03:00 | Imbalanced classification | Accuracy trap, confusion matrix, PR-AUC |
| 03:00-03:35 | SMOTE and undersampling | Resampling only the training data |
| 03:35-04:00 | Comparison and discussion | Business trade-offs, assignment briefing |

## Learning objectives

By the end, participants should be able to:

1. profile missing values and distinguish MCAR, MAR, and MNAR conceptually;
2. choose a defensible imputation strategy;
3. detect outliers using domain knowledge and IQR;
4. distinguish invalid data from legitimate rare events;
5. explain why an imbalanced model can have misleadingly high accuracy;
6. apply SMOTE and undersampling without leakage;
7. compare strategies using recall, F1, balanced accuracy, ROC-AUC, and PR-AUC;
8. use an `imblearn` pipeline during cross-validation.

## Discussion prompts

- Is a 200% brake-wear value an outlier, an error, or a different unit?
- Should a 500,000 km commercial vehicle be deleted?
- What is more expensive: missing a high-risk vehicle or calling a low-risk customer?
- Why does SMOTE improve recall while reducing precision?
- Why is the baseline accuracy higher even though its minority recall is much lower?
- When would class weighting be preferable to resampling?

## Common learner mistakes

- Replacing missing values in the entire dataframe before splitting.
- Applying SMOTE to both training and test data.
- Using accuracy as the only metric.
- Treating all statistically rare values as errors.
- Using `pandas.get_dummies` separately on training and test data.
- Forgetting `handle_unknown='ignore'` in one-hot encoding.
- Using vanilla SMOTE directly on raw categorical strings.
- Selecting a 50:50 balance automatically without validating business performance.

# Final Results Summary

## Dataset quality

- Raw rows: **3,000**
- Raw columns: **13**
- Intentionally missing cells: **1,080**
- High Risk prevalence: **10.23%**
- Training rows: **2,250**
- Test rows: **750**

## Preprocessing

- Numeric missing values: median imputation with missing indicators.
- Categorical missing values: most-frequent imputation.
- Outliers: IQR boundaries learned only from training data, followed by capping.
- Categories: one-hot encoded with unknown-category protection.
- Numeric values: standard scaled after imputation.
- Balancing: applied only to the training data.

## Model comparison conclusion

The unbalanced baseline reached approximately **93.5% accuracy**, but its High Risk recall was only about **40.3%**. It missed 46 of the 77 High Risk records in the test set.

SMOTE reduced overall accuracy to approximately **87.3%**, but increased High Risk recall to about **79.2%** and achieved the highest minority F1 score in this generated run. It identified 61 of 77 High Risk records but created more false-positive alerts.

## Selected method

**SMOTE**, selected by minority-class F1 with recall and PR-AUC as tie-breakers.

This is a case-study result, not a universal rule. Production selection should use validated business costs, operational capacity, probability calibration, subgroup checks, and threshold tuning.

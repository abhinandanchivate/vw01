# Multiple-Choice Questions with Answers

1. **Which imputation is usually robust for skewed numeric data?**  
   A. Mean  B. Median  C. Zero  D. Random deletion  
   **Answer: B**

2. **What does MCAR mean?**  
   A. Missingness depends on the target  B. Missingness is completely unrelated to observed/unobserved data  C. Values are always zero  D. Categories are imbalanced  
   **Answer: B**

3. **Why add a missing indicator?**  
   A. To remove every row  B. To preserve whether absence itself carries information  C. To scale categories  D. To increase test size  
   **Answer: B**

4. **Which is the correct order?**  
   A. SMOTE then split  B. Impute full data then split  C. Split, fit preprocessing on train, transform test  D. Balance test then evaluate  
   **Answer: C**

5. **IQR equals:**  
   A. Q1 + Q3  B. Q3 - Q1  C. Mean / standard deviation  D. Maximum - minimum  
   **Answer: B**

6. **An outlier is always an error.**  
   A. True  B. False  
   **Answer: B**

7. **Capping an outlier means:**  
   A. Deleting the target  B. Replacing values beyond boundaries with boundary values  C. Duplicating the row  D. Converting it to text  
   **Answer: B**

8. **Which scaler is often robust to outliers?**  
   A. RobustScaler  B. OneHotEncoder  C. LabelEncoder  D. CountVectorizer  
   **Answer: A**

9. **SMOTE creates:**  
   A. Copies of majority points only  B. Synthetic minority points between neighbours  C. A new test set  D. Missing values  
   **Answer: B**

10. **Where should SMOTE be applied?**  
    A. Entire dataset before split  B. Test data only  C. Training data only  D. Target column only  
    **Answer: C**

11. **What is a major undersampling risk?**  
    A. It creates missing values  B. It discards useful majority information  C. It cannot reduce training time  D. It duplicates data  
    **Answer: B**

12. **Class weights mainly change:**  
    A. Column names  B. Penalty/loss contribution of classes  C. Number of test rows  D. Feature units  
    **Answer: B**

13. **A 95% accurate model predicts no rare failures. What is wrong?**  
    A. Nothing  B. Accuracy hides zero minority recall  C. Dataset is balanced  D. Model has perfect PR-AUC  
    **Answer: B**

14. **Which metric focuses on finding actual positives?**  
    A. Recall  B. Specificity  C. R-squared  D. MAE  
    **Answer: A**

15. **Which metric is often valuable under severe imbalance?**  
    A. PR-AUC  B. Training loss only  C. Adjusted R-squared  D. MAPE  
    **Answer: A**

16. **Balanced accuracy is:**  
    A. Majority accuracy only  B. Average of sensitivity and specificity  C. Precision + recall  D. Number of balanced rows  
    **Answer: B**

17. **Why use `stratify=y` in a split?**  
    A. To normalize features  B. To approximately preserve class proportions  C. To create synthetic data  D. To remove outliers  
    **Answer: B**

18. **Why use `handle_unknown='ignore'`?**  
    A. To ignore the target  B. To handle unseen test/inference categories safely  C. To delete missing rows  D. To calculate IQR  
    **Answer: B**

19. **Which SMOTE variant supports mixed numeric/categorical features?**  
    A. SMOTENC  B. PCA  C. KMeans  D. StandardScaler  
    **Answer: A**

20. **Why place a sampler inside an imbalanced-learn pipeline?**  
    A. To balance the test fold  B. To apply resampling only inside each training fold  C. To remove all categories  D. To avoid cross-validation  
    **Answer: B**

21. **A false negative in urgent-service prediction means:**  
    A. Low-risk vehicle predicted high risk  B. High-risk vehicle predicted low risk  C. Correct high-risk prediction  D. Correct low-risk prediction  
    **Answer: B**

22. **Threshold tuning should normally use:**  
    A. Final test set repeatedly  B. Validation data and business costs  C. Raw target names only  D. Random values  
    **Answer: B**

23. **Which can detect multivariate anomalies?**  
    A. Isolation Forest  B. Mode imputation  C. One-hot encoding  D. Stratification  
    **Answer: A**

24. **Why monitor capping rate in production?**  
    A. A rising rate can indicate drift or data errors  B. To improve file compression  C. To rename columns  D. To balance classes  
    **Answer: A**

25. **The best balancing method is always SMOTE.**  
    A. True  B. False  
    **Answer: B**

# Hands-On Assignment - No Solution

## Business problem

A service network wants to identify vehicles likely to require urgent maintenance within 30 days. The supplied dataset contains missing values, outliers, and an imbalanced target.

## Tasks

1. Load `vehicle_service_risk_raw.csv` and display shape, data types, duplicates, target distribution, and descriptive statistics.
2. Produce a missing-value report with count and percentage.
3. Explain which missingness mechanism might apply to battery voltage and service gap.
4. Split the data using a stratified 75:25 train-test split.
5. Detect outliers for all numeric columns using the IQR method based on training data.
6. Decide separately for each numeric feature whether to remove, cap, transform, or retain outliers.
7. Impute numeric missing values using the median and categorical values using the most frequent category.
8. Add numeric missing indicators.
9. Encode categorical fields and scale numeric fields.
10. Train an unbalanced baseline Logistic Regression model.
11. Train a model using SMOTE.
12. Train a model using random undersampling.
13. Train a class-weighted model.
14. Compare accuracy, balanced accuracy, minority precision, minority recall, minority F1, ROC-AUC, and PR-AUC.
15. Display confusion matrices.
16. Select a method based on the cost of missing a truly high-risk vehicle.
17. Save the preprocessing logic and selected model.
18. Write five production monitoring rules.

## Expected deliverables

- Jupyter notebook
- cleaned dataset
- balancing comparison table
- model comparison table
- at least four plots
- final recommendation with business justification

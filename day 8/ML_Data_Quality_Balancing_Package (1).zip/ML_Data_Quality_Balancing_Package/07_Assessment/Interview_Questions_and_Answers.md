# Interview Questions and Model Answers

## 1. Why is median imputation often preferred to mean imputation?

The median is less affected by extreme values and skewed distributions. The mean can be pulled strongly by a few large observations.

## 2. What is the risk of imputing before splitting?

The imputed value is influenced by validation/test observations, so information leaks into training and evaluation becomes optimistic.

## 3. Should every outlier be removed?

No. An outlier may be a data error, a valid rare event, a new population, or the exact event the model must detect. Removal requires statistical and domain justification.

## 4. Why does an imbalanced baseline often show high accuracy?

The majority class dominates the metric. Predicting nearly every record as majority can be accurate overall while failing most minority cases.

## 5. How does SMOTE work?

It selects a minority example and one of its minority nearest neighbours, then creates a synthetic point along the line segment between them.

## 6. When can SMOTE be harmful?

When minority examples are noisy, overlap the majority, are extremely sparse, contain categorical structures handled incorrectly, or cross entity/time boundaries.

## 7. Difference between oversampling and class weighting?

Oversampling changes the effective training dataset. Class weighting keeps the rows unchanged but changes the loss penalty applied to errors from each class.

## 8. Why should the test set remain imbalanced?

It should represent real deployment prevalence. Balancing it changes the operating conditions and gives misleading precision and workload estimates.

## 9. ROC-AUC versus PR-AUC?

ROC-AUC evaluates ranking across sensitivity and false-positive rate. PR-AUC focuses on precision and recall for the positive class and is often more informative when positives are rare.

## 10. How do you handle imbalance during cross-validation?

Use an `imblearn.pipeline.Pipeline` containing preprocessing, sampler, and model. Cross-validation then fits/resamples only each training fold and evaluates on the untouched fold.

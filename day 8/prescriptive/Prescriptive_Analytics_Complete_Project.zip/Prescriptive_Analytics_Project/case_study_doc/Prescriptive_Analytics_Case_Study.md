# Prescriptive Analytics Case Study

## Automobile Predictive Maintenance and Service Optimization

**Purpose:** Convert predicted vehicle-failure risk into an executable service plan that identifies the action, timing, workshop, spare parts, customer communication, and escalation path.

**Case-study type:** End-to-end training case with sample data, architecture, Python implementation, prescriptive decision logic, capacity and inventory constraints, reports, controls, test cases, and business KPIs.

---

## 1. Prescriptive Analytics - 5W1H

| Question | Explanation |
|---|---|
| **What?** | Prescriptive analytics recommends the best action after considering predictions, rules, costs, constraints, and business objectives. |
| **Why?** | A prediction such as “89% failure risk” does not itself prevent a breakdown. The business needs to know what to do, when to do it, what resources are required, and what to do when capacity or parts are unavailable. |
| **Who?** | Service operations managers, workshop planners, data scientists, customer-care teams, inventory planners, fleet managers, and compliance or safety teams. |
| **When?** | After descriptive analysis explains the past and predictive analytics estimates the future, especially when a decision must be made under limited time, budget, people, capacity, or inventory. |
| **Where?** | Predictive maintenance, healthcare treatment planning, supply-chain replenishment, workforce scheduling, pricing, fraud response, route optimization, and customer-retention programs. |
| **How?** | Combine risk predictions with decision rules, expected-value calculations, optimization or prioritization, operational constraints, action automation, and feedback monitoring. |

**Primary question answered:** **What should the organization do next?**

---

## 2. Business Problem

A vehicle manufacturer and its service network want to reduce unexpected breakdowns, emergency repairs, customer complaints, towing costs, and safety incidents. The organization already collects vehicle and service data and can estimate the probability of failure in the next 30 days.

The missing capability is an operational decision system. For each vehicle, it must decide:

1. Whether intervention is required.
2. The safest and most economical action.
3. How urgently the action must be completed.
4. Which workshop should handle it.
5. Which spare parts must be reserved.
6. Whether workshop capacity and parts inventory make the action executable.
7. What escalation is required if resources are unavailable.
8. How the result should be communicated and measured.

---

## 3. Business Objectives and Success Criteria

| Objective | Measurement |
|---|---|
| Reduce unexpected breakdowns | Breakdown rate among contacted high-risk vehicles |
| Prioritize safety-critical vehicles | Percentage of safety overrides actioned within 24 hours |
| Use workshop capacity effectively | Reserved slots divided by available urgent slots |
| Reduce parts-related delays | Parts escalations resolved before scheduled appointment |
| Improve customer experience | Contact success rate, appointment acceptance, complaint reduction |
| Demonstrate financial value | Expected and realized savings after intervention cost |
| Maintain trustworthy decisions | Audit trail, data-quality pass rate, policy compliance, model monitoring |

### Acceptance targets for the case study

- Every valid vehicle receives a risk category, recommended action, timeframe, priority score, and explanation.
- Safety overrides take precedence over normal risk thresholds.
- Near-term service slots are assigned in priority order.
- Spare-parts stock is consumed as jobs are reserved.
- Unavailable parts produce an explicit parts escalation.
- Exhausted workshop capacity produces a capacity escalation.
- All decisions are exported to an action report and summarized for management.

---

## 4. Stakeholders and Responsibilities

| Stakeholder | Responsibility |
|---|---|
| Service operations manager | Owns service policy, capacity rules, and execution KPIs |
| Data science team | Maintains the failure-risk model and probability quality |
| Workshop planner | Confirms slots, technicians, and alternate workshops |
| Inventory planner | Reserves, transfers, or procures required parts |
| Customer-care team | Contacts customers and records appointment response |
| Safety/compliance team | Defines non-negotiable safety overrides and audit controls |
| IT/data engineering | Maintains ingestion, APIs, data quality, security, and monitoring |
| Management | Reviews financial value, risk reduction, and service-network performance |

---

## 5. Data Inputs

### 5.1 Vehicle and customer data

| Feature | Meaning | Example |
|---|---|---|
| mileage_km | Total vehicle mileage | 72,000 |
| service_gap_months | Months since last service | 14 |
| engine_alerts | Recent engine warning count | 5 |
| brake_wear_percent | Estimated brake wear | 82% |
| battery_voltage | Battery condition | Low |
| customer_complaints | Recent complaint count | 3 |
| vehicle_age_years | Age of vehicle | 6.5 |
| breakdown_history | Previous breakdown count | 2 |
| customer_priority | Standard, Fleet, or VIP | Fleet |
| workshop_region | Nearest service region | Pune West |
| actual_failure_30d | Historical training target | 0 or 1 |

### 5.2 Operational constraints

- Workshop slots available today and during the next 48 hours.
- Mobile-technician capacity.
- Regional stock of brake kits, batteries, and engine sensors.
- Service-region ownership and alternate-workshop escalation.
- Safety rules that cannot be overridden by cost optimization.

---

## 6. Architecture Flow

![Prescriptive analytics architecture](02_prescriptive_architecture.png)

### Architecture explanation

1. **Data sources:** telematics, service history, CRM, workshop capacity, and parts inventory.
2. **Ingestion and validation:** batch, API, or streaming data is checked for missing values, invalid categories, impossible ranges, and duplicate identifiers.
3. **Feature preparation:** numerical values are scaled and categorical values are encoded.
4. **Predictive risk model:** produces a probability of failure in the next 30 days.
5. **Prescriptive engine:** applies safety policies, calculates expected value, ranks cases, and checks capacity and inventory constraints.
6. **Action systems:** customer notification, booking, parts reservation, transfer or procurement, and management reporting.
7. **Feedback:** service completion, actual failures, cost, and customer response are captured.
8. **Governance:** model performance, policy compliance, drift, fairness, data quality, and audit logs are monitored.

---

## 7. Decision Workflow

![Prescriptive decision flow](02_prescriptive_decision_flow.png)

### Decision sequence

1. Validate the incoming record.
2. Predict failure probability.
3. Check safety overrides.
4. Assign risk band and base action.
5. Estimate loss without action and intervention cost.
6. Calculate expected savings and priority score.
7. Check workshop capacity.
8. Check parts availability.
9. Reserve the slot and parts or raise an escalation.
10. Notify the customer and publish the action report.
11. Capture the outcome and use it to improve the model and policy.

---

## 8. Prescriptive Decision Rules

| Condition | Risk / priority | Prescribed action | Target time |
|---|---:|---|---|
| Brake wear >= 90% or engine alerts >= 8 | Critical / 1 | Immediate safety intervention | Within 24 hours |
| Failure probability >= 0.80 | Critical / 1 | Immediate safety intervention | Within 24 hours |
| Probability 0.65-0.7999 | High / 2 | Priority workshop inspection | Within 48 hours |
| Probability 0.40-0.6499 | Medium / 3 | Planned preventive service | Within 7 days |
| Probability 0.20-0.3999 | Low / 4 | Remote diagnostic and monitoring | Within 30 days |
| Probability < 0.20 | Low / 5 | No immediate intervention | Next regular service |

### Parts-reservation rules

| Observed condition | Part to reserve |
|---|---|
| Brake wear >= 75% | Brake Kit |
| Battery voltage = Low | Battery |
| Engine alerts >= 4 | Engine Sensor |

### Important rule precedence

A safety override is evaluated before normal risk thresholds. Therefore, a vehicle may receive a **Critical** action even when its model probability is below 0.80. This avoids allowing a statistical model to overrule a clear safety condition.

---

## 9. Business-Value Calculation

The engine compares the expected cost of doing nothing with the expected cost after intervention.

```text
Expected loss without action
    = Predicted failure probability x Estimated breakdown cost

Expected loss after action
    = Residual failure probability x Estimated breakdown cost
      + Intervention cost

Expected savings
    = Expected loss without action - Expected loss after action
```

The demonstration uses different effectiveness assumptions by action urgency. These are case-study assumptions and must be replaced with validated historical effectiveness values before production use.

### Priority score

The priority score combines:

- Failure probability.
- Safety bonus.
- Customer-priority bonus.
- Complaint bonus.
- Brake-wear severity.

The score is used only after the non-negotiable priority rank. A Priority 1 case is always considered before Priority 2, even if the Priority 2 score is numerically high.

---

## 10. Resource Optimization Logic

The case study uses a transparent greedy allocation approach:

1. Group vehicles by workshop region.
2. Sort by priority rank and then priority score.
3. Check whether required parts are available.
4. Allocate today's slots first.
5. Allocate next-48-hour slots when today's capacity is exhausted.
6. Decrement parts stock after every confirmed reservation.
7. Raise a parts escalation when stock is unavailable.
8. Raise a capacity escalation when all urgent slots are used.

This approach is explainable and suitable for training. A production system may replace it with mathematical optimization when there are more complex constraints such as technician skills, bay type, travel time, appointment preferences, service duration, or multi-period inventory.

---

## 11. Worked Vehicle Example

The package selects a representative case from the generated data.

| Item | Value |
|---|---|
| Vehicle ID | VEH-0469 |
| Mileage | 85,650 km |
| Service gap | 11.7 months |
| Engine alerts | 3 |
| Brake wear | 82.7% |
| Battery | Normal |
| Complaints | 2 |
| Customer priority | VIP |
| Workshop | Pune West |
| Predicted failure probability | 77.37% |
| Risk category | High |
| Prescribed action | Priority workshop inspection |
| Target time | Within 48 hours |
| Required parts | Brake Kit |
| Scheduled window | Today |
| Execution status | Slot reserved |
| Estimated intervention cost | INR 13,500.00 |
| Expected savings | INR 40,357.71 |

### Interpretation

The model predicts a high probability of failure. Brake wear also requires a brake kit. The prescriptive engine assigns a Priority 2 workshop inspection, confirms parts availability, reserves a slot today, and estimates the financial benefit of acting before a breakdown occurs.

---

## 12. Demonstration Results

The supplied dataset contains **500 vehicles**.

### Predictive model results

| Metric | Result |
|---|---:|
| Test accuracy | 0.736 |
| ROC-AUC | 0.785 |
| Test confusion matrix | [[73, 10], [23, 19]] |

The model is included to supply risk probabilities for the prescriptive layer. Its metrics are demonstration results from synthetic data, not production performance claims.

### Prescriptive output results

| KPI | Result |
|---|---:|
| Critical and High vehicles | 96 |
| Slots reserved | 118 |
| Parts escalations | 73 |
| Capacity escalations | 50 |
| Total modeled expected savings | INR 8,278,817.77 |

### Risk summary

| risk_category   |   vehicles |   avg_failure_probability |   expected_savings_inr |
|:----------------|-----------:|--------------------------:|-----------------------:|
| Critical        |         44 |                     0.687 |            1.52277e+06 |
| High            |         52 |                     0.714 |            2.02032e+06 |
| Medium          |        145 |                     0.512 |            3.0823e+06  |
| Low             |        259 |                     0.243 |            1.65342e+06 |

### Workshop-region summary

| workshop_region   |   vehicles |   critical_high |   slots_reserved |   parts_escalations |   capacity_escalations |   expected_savings_inr |
|:------------------|-----------:|----------------:|-----------------:|--------------------:|-----------------------:|-----------------------:|
| Mumbai            |         92 |              20 |               30 |                   0 |                     13 |            1.54439e+06 |
| Pune Central      |        124 |              21 |               24 |                  28 |                      2 |            1.83784e+06 |
| Pune North        |        136 |              29 |               28 |                  31 |                     10 |            2.3998e+06  |
| Pune West         |        148 |              26 |               36 |                  14 |                     25 |            2.49678e+06 |

---

## 13. Required Reports

### 13.1 Vehicle action report

One row per vehicle containing:

- Predicted probability and risk category.
- Recommended action and timeframe.
- Priority rank and score.
- Required parts and availability.
- Scheduled window and execution status.
- Estimated costs and expected savings.
- Human-readable decision reason.

### 13.2 Management dashboard

The workbook contains:

- Executive KPIs.
- Risk-category summary.
- Workshop-region summary.
- Execution-status distribution.
- Top-priority vehicles.
- Full action report.
- Capacity, inventory, and data-dictionary sheets.

### 13.3 Model and governance report

The package includes model metrics, assumptions, validation controls, acceptance tests, and production-readiness recommendations.

---

## 14. Functional Requirements

| ID | Requirement |
|---|---|
| FR-01 | Load vehicle, workshop-capacity, and inventory data. |
| FR-02 | Validate required columns, categories, ranges, and target values. |
| FR-03 | Generate a failure probability for every valid vehicle. |
| FR-04 | Apply safety overrides before probability thresholds. |
| FR-05 | Generate action, timeframe, priority, required parts, and reason. |
| FR-06 | Calculate expected breakdown cost, intervention cost, and expected savings. |
| FR-07 | Allocate workshop slots in priority order. |
| FR-08 | Consume parts inventory only when a slot is reserved. |
| FR-09 | Produce parts and capacity escalations. |
| FR-10 | Export detailed and summarized reports. |
| FR-11 | Record enough information to audit why a decision was made. |
| FR-12 | Capture outcomes for monitoring and future improvement. |

---

## 15. Non-Functional Requirements

| Area | Requirement |
|---|---|
| Explainability | Every action must have a decision reason and traceable inputs. |
| Reliability | Re-running with the same data and random seed must reproduce the result. |
| Performance | Batch processing must complete within the agreed operational window. |
| Security | Customer and vehicle identifiers must be access-controlled and encrypted where appropriate. |
| Privacy | Use only necessary customer attributes and enforce retention rules. |
| Auditability | Store model version, policy version, timestamp, and action status. |
| Availability | Escalation and safety decisions must remain available during partial-system failures. |
| Maintainability | Thresholds, costs, effectiveness assumptions, and capacity rules should be configurable. |

---

## 16. Data-Quality Controls

- Vehicle ID is present and unique.
- Mileage, service gap, brake wear, and age are within agreed ranges.
- Battery state is either Low or Normal.
- Customer priority and workshop region use approved categories.
- Failure target is 0 or 1 for training data.
- Capacity and inventory values are non-negative integers.
- Duplicate events and stale records are flagged.
- Missing safety fields are sent to a manual-review queue rather than treated as low risk.

---

## 17. Testing and Acceptance

| Test | Input / condition | Expected result |
|---|---|---|
| Safety override | Brake wear = 95%, probability = 0.45 | Critical action within 24 hours |
| High risk | Probability = 0.72, no safety override | Priority workshop inspection within 48 hours |
| Medium risk | Probability = 0.50 | Planned service within 7 days |
| Low risk | Probability = 0.25 | Remote diagnostic and monitoring |
| No action | Probability = 0.10 | Next regular service |
| Parts shortage | Required part stock reaches zero | Parts escalation, no false confirmed reservation |
| Capacity shortage | All near-term slots consumed | Capacity escalation |
| Invalid category | battery_voltage = Unknown | Validation error or exception queue |
| Reproducibility | Same data and seed | Same risk model and report order |
| Auditability | Any action row | Probability, rule, cost, constraints, and reason are traceable |

---

## 18. Risks, Limitations, and Controls

| Risk / limitation | Control |
|---|---|
| Synthetic training data | Replace with representative historical data and revalidate all metrics. |
| Incorrect cost assumptions | Obtain finance-approved cost and effectiveness values. |
| Probability calibration | Evaluate calibration curves and recalibrate before expected-value decisions. |
| Bias across regions or customer tiers | Compare error and action rates by segment; do not use customer tier to deny safety service. |
| Inventory data delay | Use reservation transactions and timestamps; reconcile with ERP. |
| Capacity changes after recommendation | Re-check availability at booking confirmation. |
| Automation error | Keep human approval for safety-sensitive or high-cost actions during rollout. |
| Model drift | Monitor feature, probability, action, and outcome drift. |

---

## 19. Production Enhancement Roadmap

1. Replace the synthetic dataset with governed operational data.
2. Add probability calibration and cost-sensitive evaluation.
3. Store policies in a configurable decision table.
4. Integrate real-time workshop calendars and ERP stock reservations.
5. Add service-duration, technician-skill, bay-type, and customer-preference constraints.
6. Use an optimization solver for multi-period scheduling when needed.
7. Add API endpoints and event-driven action updates.
8. Add model registry, policy versioning, audit logs, and approval workflow.
9. Measure realized savings and failure avoidance, not only modeled expected savings.
10. Run controlled pilots before full automation.

---

## 20. Suggested Training Flow

| Duration | Activity |
|---:|---|
| 15 min | Prescriptive analytics concept and 5W1H |
| 15 min | Business problem, data, objectives, and stakeholders |
| 15 min | Architecture and decision workflow |
| 20 min | Python model and prescription logic walkthrough |
| 15 min | Capacity, inventory, and escalation demonstration |
| 10 min | Reports, KPIs, testing, risks, and production roadmap |

---

## 21. Package Deliverables

- Case-study document in Markdown, Word, and PDF.
- Architecture and decision-flow diagrams.
- Vehicle input, workshop-capacity, and parts-inventory CSV files.
- End-to-end Python solution and requirements file.
- Detailed vehicle action report.
- Risk and workshop-region summaries.
- Excel dashboard.
- Executive report.
- Data dictionary.
- Requirements and acceptance-test document.
- README with recommended file order.

---

## 22. Final Business Interpretation

Descriptive analytics explains which vehicles failed and what patterns were observed. Predictive analytics estimates which vehicles are likely to fail. Prescriptive analytics closes the operational gap by deciding which action should be taken, when it should occur, what resources are needed, whether the action is feasible, and how exceptions must be escalated.

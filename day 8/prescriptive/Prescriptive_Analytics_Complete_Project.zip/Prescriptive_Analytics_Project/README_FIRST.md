# Prescriptive Analytics — Automobile Service Project

This package is a complete, trainer-ready prescriptive analytics case study. It starts with predicted vehicle-failure probability and converts it into an executable service decision while considering safety, workshop capacity, spare-parts stock, urgency, customer priority, intervention cost, and expected savings.

## Recommended learning order

1. Open `case_study_doc/Prescriptive_Analytics_Case_Study.pdf` or the editable DOCX version.
2. Review `supporting_files/prescriptive_architecture.png` and `prescriptive_decision_flow.png`.
3. Read `dataset/data_dictionary.csv`, then inspect the three input datasets.
4. Run `source_code/prescriptive_analytics_notebook.ipynb` or `source_code/prescriptive_analytics_solution.py`.
5. Review all generated and pre-generated reports in `output/`.
6. Run `source_code/validate_project.py` to confirm that the results are complete and internally consistent.

## Folder structure

```text
Prescriptive_Analytics_Project/
├── README_FIRST.md
├── run_analysis.sh
├── run_analysis.bat
├── case_study_doc/
│   ├── Prescriptive_Analytics_Case_Study.docx
│   ├── Prescriptive_Analytics_Case_Study.pdf
│   └── Prescriptive_Analytics_Case_Study.md
├── dataset/
│   ├── vehicle_prescriptive_input.csv
│   ├── workshop_capacity.csv
│   ├── parts_inventory.csv
│   ├── data_dictionary.csv
│   └── sample_case_vehicle.json
├── source_code/
│   ├── prescriptive_analytics_solution.py
│   ├── prescriptive_analytics_notebook.ipynb
│   ├── validate_project.py
│   └── requirements.txt
├── output/
│   ├── prescriptive_action_report.csv
│   ├── risk_summary.csv
│   ├── region_summary.csv
│   ├── model_metrics.json
│   ├── run_summary.txt
│   ├── Prescriptive_Analytics_Dashboard.xlsx
│   ├── dashboard_preview.png
│   ├── Executive_Prescriptive_Analytics_Report.docx
│   ├── Executive_Prescriptive_Analytics_Report.pdf
│   └── Validation_Results.md
└── supporting_files/
    ├── prescriptive_architecture.png/.svg/.dot
    ├── prescriptive_decision_flow.png/.dot
    ├── Business_Requirements_and_Test_Cases.md
    └── Run_in_Colab_or_Jupyter.md
```

## Run the project

### Windows

Double-click `run_analysis.bat`, or run:

```bat
python -m pip install -r source_code\requirements.txt
python source_code\prescriptive_analytics_solution.py
python source_code\validate_project.py
```

### macOS or Linux

```bash
chmod +x run_analysis.sh
./run_analysis.sh
```

### Direct Python execution

```bash
python -m pip install -r source_code/requirements.txt
python source_code/prescriptive_analytics_solution.py
python source_code/validate_project.py
```

The Python solution reads inputs only from `dataset/` and writes its generated reports only to `output/`.

## Main outputs

- `prescriptive_action_report.csv`: recommendation, timeframe, risk, priority, required parts, schedule, escalation status, cost, and expected savings for every vehicle.
- `risk_summary.csv`: management summary by Critical, High, Medium, and Low risk.
- `region_summary.csv`: workshop-region workload, reservations, and escalation totals.
- `model_metrics.json`: accuracy, ROC-AUC, confusion matrix, and classification report.
- `Prescriptive_Analytics_Dashboard.xlsx`: formatted management dashboard.
- `Executive_Prescriptive_Analytics_Report.pdf`: presentation-ready output report.

## Current verified result

- Vehicle records processed: 500
- Model accuracy: 0.736
- ROC-AUC: 0.7846
- Critical or High cases: 96
- Workshop slots reserved: 118
- Estimated expected savings: INR 8,278,817.77

## Included supporting documents

The package also includes the data dictionary, architecture source files, decision-flow source files, business requirements, functional test cases, Colab/Jupyter instructions, an automated validation script, and a checksum list.

> The dataset and financial values are synthetic and are intended for teaching, demonstrations, and practice.

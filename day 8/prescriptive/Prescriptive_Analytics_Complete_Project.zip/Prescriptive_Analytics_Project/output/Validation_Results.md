# Validation Results

The following automated checks were run against the supplied action report.

| Check | Status | Evidence |
|---|---|---|
| All 500 input vehicles appear in action report | PASS | 500 rows |
| All decision fields are populated | PASS | No missing values |
| Safety overrides are Priority 1 | PASS | 30 safety overrides checked |
| Pune West slot allocation does not exceed capacity | PASS | 36 reserved / 36 available |
| Pune North slot allocation does not exceed capacity | PASS | 28 reserved / 28 available |
| Pune Central slot allocation does not exceed capacity | PASS | 24 reserved / 24 available |
| Mumbai slot allocation does not exceed capacity | PASS | 30 reserved / 30 available |
| Pune West Brake Kit reservations do not exceed stock | PASS | 16 reserved / 18 stock |
| Pune West Battery reservations do not exceed stock | PASS | 16 reserved / 16 stock |
| Pune West Engine Sensor reservations do not exceed stock | PASS | 2 reserved / 12 stock |
| Pune North Brake Kit reservations do not exceed stock | PASS | 10 reserved / 10 stock |
| Pune North Battery reservations do not exceed stock | PASS | 12 reserved / 12 stock |
| Pune North Engine Sensor reservations do not exceed stock | PASS | 9 reserved / 9 stock |
| Pune Central Brake Kit reservations do not exceed stock | PASS | 7 reserved / 7 stock |
| Pune Central Battery reservations do not exceed stock | PASS | 8 reserved / 8 stock |
| Pune Central Engine Sensor reservations do not exceed stock | PASS | 6 reserved / 6 stock |
| Mumbai Brake Kit reservations do not exceed stock | PASS | 11 reserved / 15 stock |
| Mumbai Battery reservations do not exceed stock | PASS | 11 reserved / 14 stock |
| Mumbai Engine Sensor reservations do not exceed stock | PASS | 8 reserved / 11 stock |
| Risk summary reconciles to action report | PASS | 500 summarized |
| No invalid probability values | PASS | min=0.0380, max=0.9154 |

**Overall result:** PASS

These checks validate internal consistency of the training package. They do not replace production data validation, model validation, security testing, or operational user acceptance testing.
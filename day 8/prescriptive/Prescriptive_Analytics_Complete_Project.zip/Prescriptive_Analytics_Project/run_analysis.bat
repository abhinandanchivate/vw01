@echo off
cd /d %~dp0
python -m pip install -r source_code\requirements.txt
python source_code\prescriptive_analytics_solution.py
python source_code\validate_project.py
pause

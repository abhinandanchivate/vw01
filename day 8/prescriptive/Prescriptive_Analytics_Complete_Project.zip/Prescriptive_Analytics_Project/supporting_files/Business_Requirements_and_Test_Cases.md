# Business Requirements and Acceptance Tests

## Project
Automobile Prescriptive Maintenance and Service Optimization

## Scope
Create executable service prescriptions from vehicle failure probabilities while respecting safety policy, workshop capacity, parts inventory, customer urgency, and financial value.

## Requirement Traceability Matrix

| ID | Requirement | Input | Output | Acceptance evidence |
|---|---|---|---|---|
| FR-01 | Ingest source data | Vehicle, capacity, inventory CSVs | Validated dataframes | Script completes without missing-column error |
| FR-02 | Validate vehicle data | Required fields and categories | Accepted row or validation exception | Invalid category test fails clearly |
| FR-03 | Predict failure risk | Vehicle features | 0-1 probability | Every valid row has probability |
| FR-04 | Apply safety override | Brake wear and engine alerts | Priority 1 action | 95% brake-wear test is Critical |
| FR-05 | Generate prescription | Probability and policies | Action, timeframe, reason | All action-report fields populated |
| FR-06 | Calculate business value | Probability, cost, effectiveness | Expected savings | Formula reproducible from row data |
| FR-07 | Allocate capacity | Priority and regional slots | Scheduled window | Allocation never exceeds configured slots |
| FR-08 | Allocate inventory | Required parts and regional stock | Parts availability/status | Reserved parts never exceed opening stock |
| FR-09 | Escalate infeasible cases | Capacity or stock shortage | Explicit escalation | No infeasible case marked as confirmed slot |
| FR-10 | Produce reports | Decision result | CSV, dashboard, executive report | Files created and totals reconcile |
| NFR-01 | Explainability | Decision inputs and policy | Decision reason | Reason available for every row |
| NFR-02 | Reproducibility | Fixed seed and same input | Same results | Second run matches first run |
| NFR-03 | Auditability | Model/policy/action metadata | Trace record | Version fields included in production design |

## Detailed Test Cases

| Test ID | Scenario | Test data | Expected output |
|---|---|---|---|
| TC-01 | Safety override | brake_wear_percent=95, probability below 0.80 | Immediate safety intervention; Priority 1; within 24 hours |
| TC-02 | Engine safety override | engine_alerts=8 | Immediate safety intervention |
| TC-03 | High probability | probability=0.75 | Priority workshop inspection; Priority 2 |
| TC-04 | Medium probability | probability=0.50 | Planned preventive service; Priority 3 |
| TC-05 | Monitoring | probability=0.30 | Remote diagnostic and monitoring |
| TC-06 | Regular service | probability=0.10 | No immediate intervention |
| TC-07 | Brake part rule | brake_wear_percent=80 | Brake Kit listed |
| TC-08 | Battery part rule | battery_voltage=Low | Battery listed |
| TC-09 | Sensor part rule | engine_alerts=5 | Engine Sensor listed |
| TC-10 | Inventory exhaustion | Required part stock becomes zero | Parts escalation required |
| TC-11 | Capacity exhaustion | Today and next-48-hour slots become zero | Capacity escalation required |
| TC-12 | Invalid battery category | battery_voltage=Unknown | Clear validation failure |
| TC-13 | Missing input file | capacity file removed | Clear FileNotFoundError |
| TC-14 | Duplicate vehicle | duplicate vehicle_id | Data-quality control flags duplicate in production implementation |
| TC-15 | Report reconciliation | Sum detailed expected savings | Equals summary expected savings |

## Definition of Done

- Python program runs with supplied files.
- Detailed report contains 500 vehicles.
- Risk, region, execution-status, and savings totals reconcile.
- Architecture and decision flow are documented.
- Assumptions and limitations are explicitly stated.
- Safety overrides, inventory shortages, and capacity shortages are testable.

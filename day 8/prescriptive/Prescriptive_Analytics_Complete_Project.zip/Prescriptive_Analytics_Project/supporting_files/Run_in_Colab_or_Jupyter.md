# Run in Google Colab or Jupyter

1. Upload `03_vehicle_prescriptive_input.csv`, `04_workshop_capacity.csv`, `05_parts_inventory.csv`, and `12_prescriptive_analytics_solution.py` into the same working folder.
2. Install dependencies:

```python
!pip install pandas numpy scikit-learn
```

3. Run the script:

```python
%run 12_prescriptive_analytics_solution.py
```

The code uses:

```python
BASE_DIR = Path(__file__).resolve().parent if "__file__" in globals() else Path.cwd()
```

This avoids the `NameError: __file__ is not defined` issue that occurs in notebooks.

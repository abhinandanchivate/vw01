"""Validate the project structure, datasets, and generated output reports."""

from __future__ import annotations

import json
from pathlib import Path

import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DATASET_DIR = PROJECT_ROOT / "dataset"
OUTPUT_DIR = PROJECT_ROOT / "output"

REQUIRED_FILES = [
    DATASET_DIR / "vehicle_prescriptive_input.csv",
    DATASET_DIR / "workshop_capacity.csv",
    DATASET_DIR / "parts_inventory.csv",
    DATASET_DIR / "data_dictionary.csv",
    OUTPUT_DIR / "prescriptive_action_report.csv",
    OUTPUT_DIR / "risk_summary.csv",
    OUTPUT_DIR / "region_summary.csv",
    OUTPUT_DIR / "model_metrics.json",
    OUTPUT_DIR / "Prescriptive_Analytics_Dashboard.xlsx",
    OUTPUT_DIR / "Executive_Prescriptive_Analytics_Report.pdf",
]


def main() -> None:
    missing = [str(path.relative_to(PROJECT_ROOT)) for path in REQUIRED_FILES if not path.exists()]
    if missing:
        raise FileNotFoundError("Missing required files:\n- " + "\n- ".join(missing))

    vehicles = pd.read_csv(DATASET_DIR / "vehicle_prescriptive_input.csv")
    actions = pd.read_csv(OUTPUT_DIR / "prescriptive_action_report.csv")
    risk = pd.read_csv(OUTPUT_DIR / "risk_summary.csv")
    regions = pd.read_csv(OUTPUT_DIR / "region_summary.csv")
    metrics = json.loads((OUTPUT_DIR / "model_metrics.json").read_text(encoding="utf-8"))

    assert len(vehicles) == len(actions), "Input and output row counts do not match."
    assert actions["vehicle_id"].is_unique, "vehicle_id must be unique in the action report."
    assert actions["predicted_failure_probability"].between(0, 1).all()
    assert int(risk["vehicles"].sum()) == len(actions)
    assert int(regions["vehicles"].sum()) == len(actions)
    assert 0 <= float(metrics["accuracy"]) <= 1
    assert 0 <= float(metrics["roc_auc"]) <= 1

    print("Project validation passed.")
    print(f"Vehicle records: {len(vehicles):,}")
    print(f"Action records: {len(actions):,}")
    print(f"Risk categories: {len(risk):,}")
    print(f"Workshop regions: {len(regions):,}")
    print(f"Accuracy: {metrics['accuracy']}")
    print(f"ROC-AUC: {metrics['roc_auc']}")


if __name__ == "__main__":
    main()

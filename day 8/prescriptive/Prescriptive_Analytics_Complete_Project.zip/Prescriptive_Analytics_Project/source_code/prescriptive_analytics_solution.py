"""Automobile Prescriptive Analytics - end-to-end reference solution.

The program:
1. Loads vehicle, workshop-capacity, and parts-inventory data.
2. Trains a failure-risk model.
3. Converts predictions into prescriptive actions.
4. Allocates workshop capacity and spare parts.
5. Produces action, risk-summary, region-summary, and model-metrics reports.

Run from the project root:
    python source_code/prescriptive_analytics_solution.py

Project layout:
    dataset/  -> input CSV files
    output/   -> generated reports

Notebook/Colab note:
    The path fallback avoids the common "__file__ is not defined" error.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, roc_auc_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

RANDOM_STATE = 42
SCRIPT_DIR = (
    Path(__file__).resolve().parent
    if "__file__" in globals()
    else Path.cwd() / "source_code"
)
PROJECT_ROOT = SCRIPT_DIR.parent
DATASET_DIR = PROJECT_ROOT / "dataset"
OUTPUT_DIR = PROJECT_ROOT / "output"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

VEHICLE_FILE = DATASET_DIR / "vehicle_prescriptive_input.csv"
CAPACITY_FILE = DATASET_DIR / "workshop_capacity.csv"
INVENTORY_FILE = DATASET_DIR / "parts_inventory.csv"

ACTION_REPORT_FILE = OUTPUT_DIR / "prescriptive_action_report.csv"
RISK_SUMMARY_FILE = OUTPUT_DIR / "risk_summary.csv"
REGION_SUMMARY_FILE = OUTPUT_DIR / "region_summary.csv"
METRICS_FILE = OUTPUT_DIR / "model_metrics.json"
RUN_SUMMARY_FILE = OUTPUT_DIR / "run_summary.txt"

REQUIRED_VEHICLE_COLUMNS = {
    "vehicle_id",
    "mileage_km",
    "service_gap_months",
    "engine_alerts",
    "brake_wear_percent",
    "battery_voltage",
    "customer_complaints",
    "vehicle_age_years",
    "breakdown_history",
    "customer_priority",
    "workshop_region",
    "actual_failure_30d",
}


def require_columns(data: pd.DataFrame, required: Iterable[str], file_name: str) -> None:
    """Raise a clear error when a required column is absent."""
    missing = sorted(set(required) - set(data.columns))
    if missing:
        raise ValueError(f"{file_name} is missing columns: {', '.join(missing)}")


def load_inputs() -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Load and validate source files."""
    for path in (VEHICLE_FILE, CAPACITY_FILE, INVENTORY_FILE):
        if not path.exists():
            raise FileNotFoundError(
                f"Required file not found: {path}. Keep input files inside the dataset folder."
            )

    vehicles = pd.read_csv(VEHICLE_FILE)
    capacity = pd.read_csv(CAPACITY_FILE)
    inventory = pd.read_csv(INVENTORY_FILE)

    require_columns(vehicles, REQUIRED_VEHICLE_COLUMNS, VEHICLE_FILE.name)
    require_columns(
        capacity,
        {"workshop_region", "slots_today", "slots_next_48h", "mobile_technicians"},
        CAPACITY_FILE.name,
    )
    require_columns(
        inventory,
        {"workshop_region", "part_name", "stock_on_hand", "reorder_level"},
        INVENTORY_FILE.name,
    )

    if not vehicles["battery_voltage"].isin(["Low", "Normal"]).all():
        raise ValueError("battery_voltage must contain only Low or Normal.")
    if not vehicles["actual_failure_30d"].isin([0, 1]).all():
        raise ValueError("actual_failure_30d must contain only 0 or 1.")

    return vehicles, capacity, inventory


def train_risk_model(vehicles: pd.DataFrame) -> tuple[Pipeline, dict]:
    """Train a model that provides failure probabilities for the decision engine."""
    feature_columns = [
        "mileage_km",
        "service_gap_months",
        "engine_alerts",
        "brake_wear_percent",
        "battery_voltage",
        "customer_complaints",
        "vehicle_age_years",
        "breakdown_history",
        "customer_priority",
        "workshop_region",
    ]
    numeric_columns = [
        "mileage_km",
        "service_gap_months",
        "engine_alerts",
        "brake_wear_percent",
        "customer_complaints",
        "vehicle_age_years",
        "breakdown_history",
    ]
    categorical_columns = ["battery_voltage", "customer_priority", "workshop_region"]

    X = vehicles[feature_columns]
    y = vehicles["actual_failure_30d"]

    X_train, X_test, y_train, y_test = train_test_split(
        X,
        y,
        test_size=0.25,
        random_state=RANDOM_STATE,
        stratify=y,
    )

    preprocessor = ColumnTransformer(
        transformers=[
            ("numeric", StandardScaler(), numeric_columns),
            (
                "categorical",
                OneHotEncoder(handle_unknown="ignore"),
                categorical_columns,
            ),
        ]
    )

    model = RandomForestClassifier(
        n_estimators=300,
        max_depth=8,
        min_samples_leaf=4,
        class_weight="balanced",
        random_state=RANDOM_STATE,
    )

    pipeline = Pipeline(
        steps=[("preprocess", preprocessor), ("model", model)]
    )
    pipeline.fit(X_train, y_train)

    predictions = pipeline.predict(X_test)
    probabilities = pipeline.predict_proba(X_test)[:, 1]

    metrics = {
        "accuracy": round(float(accuracy_score(y_test, predictions)), 4),
        "roc_auc": round(float(roc_auc_score(y_test, probabilities)), 4),
        "confusion_matrix": confusion_matrix(y_test, predictions).tolist(),
        "classification_report": classification_report(
            y_test, predictions, output_dict=True, zero_division=0
        ),
    }
    return pipeline, metrics


def determine_required_parts(row: pd.Series) -> list[str]:
    """Translate observed conditions into parts that should be reserved."""
    parts: list[str] = []
    if row["brake_wear_percent"] >= 75:
        parts.append("Brake Kit")
    if row["battery_voltage"] == "Low":
        parts.append("Battery")
    if row["engine_alerts"] >= 4:
        parts.append("Engine Sensor")
    return parts


def determine_base_action(row: pd.Series) -> tuple[str, str, int, str]:
    """Apply risk thresholds and safety overrides."""
    probability = float(row["predicted_failure_probability"])
    safety_override = (
        row["brake_wear_percent"] >= 90 or row["engine_alerts"] >= 8
    )

    if safety_override or probability >= 0.80:
        return (
            "Immediate safety intervention",
            "Within 24 hours",
            1,
            "Do not release vehicle until safety inspection",
        )
    if probability >= 0.65:
        return (
            "Priority workshop inspection",
            "Within 48 hours",
            2,
            "Proactive service with parts pre-reservation",
        )
    if probability >= 0.40:
        return (
            "Planned preventive service",
            "Within 7 days",
            3,
            "Customer notification and appointment booking",
        )
    if probability >= 0.20:
        return (
            "Remote diagnostic and monitoring",
            "Within 30 days",
            4,
            "Monitor alerts and send service reminder",
        )
    return (
        "No immediate intervention",
        "Next regular service",
        5,
        "Continue monitoring",
    )


def build_prescriptions(vehicles: pd.DataFrame, model: Pipeline) -> pd.DataFrame:
    """Calculate actions, costs, business value, and priority scores."""
    feature_columns = [
        "mileage_km",
        "service_gap_months",
        "engine_alerts",
        "brake_wear_percent",
        "battery_voltage",
        "customer_complaints",
        "vehicle_age_years",
        "breakdown_history",
        "customer_priority",
        "workshop_region",
    ]

    result = vehicles.copy()
    result["predicted_failure_probability"] = model.predict_proba(
        result[feature_columns]
    )[:, 1]

    prescriptions: list[dict] = []
    for _, row in result.iterrows():
        action, timeframe, priority_rank, reason = determine_base_action(row)
        parts = determine_required_parts(row)

        estimated_breakdown_cost = (
            55000
            + 12000 * row["breakdown_history"]
            + 180 * row["brake_wear_percent"]
            + 5000 * row["engine_alerts"]
        )

        estimated_intervention_cost = 1500
        if "Brake Kit" in parts:
            estimated_intervention_cost += 12000
        if "Battery" in parts:
            estimated_intervention_cost += 8000
        if "Engine Sensor" in parts:
            estimated_intervention_cost += 6000
        if priority_rank == 4:
            estimated_intervention_cost = 700
        elif priority_rank == 5:
            estimated_intervention_cost = 250

        effectiveness = (
            0.82 if priority_rank <= 2 else 0.65 if priority_rank == 3 else 0.35
        )
        expected_loss_without_action = (
            row["predicted_failure_probability"] * estimated_breakdown_cost
        )
        expected_loss_after_action = (
            (1 - effectiveness) * expected_loss_without_action
            + estimated_intervention_cost
        )
        expected_savings = expected_loss_without_action - expected_loss_after_action

        customer_bonus = {"VIP": 12, "Fleet": 7, "Standard": 0}[
            row["customer_priority"]
        ]
        complaint_bonus = min(row["customer_complaints"] * 2.5, 12.5)
        safety_bonus = (
            25
            if row["brake_wear_percent"] >= 90 or row["engine_alerts"] >= 8
            else 0
        )
        priority_score = (
            row["predicted_failure_probability"] * 100
            + customer_bonus
            + complaint_bonus
            + safety_bonus
            + 0.07 * row["brake_wear_percent"]
        )

        prescriptions.append(
            {
                "risk_category": (
                    "Critical"
                    if priority_rank == 1
                    else "High"
                    if priority_rank == 2
                    else "Medium"
                    if priority_rank == 3
                    else "Low"
                ),
                "recommended_action": action,
                "recommended_timeframe": timeframe,
                "priority_rank": priority_rank,
                "priority_score": round(priority_score, 2),
                "required_parts": ", ".join(parts) if parts else "None",
                "estimated_breakdown_cost_inr": round(
                    estimated_breakdown_cost, 2
                ),
                "estimated_intervention_cost_inr": round(
                    estimated_intervention_cost, 2
                ),
                "expected_savings_inr": round(expected_savings, 2),
                "decision_reason": reason,
            }
        )

    prescription_frame = pd.DataFrame(prescriptions)
    result = pd.concat(
        [result.reset_index(drop=True), prescription_frame.reset_index(drop=True)],
        axis=1,
    )
    return result


def allocate_resources(
    prescriptions: pd.DataFrame,
    capacity: pd.DataFrame,
    inventory: pd.DataFrame,
) -> pd.DataFrame:
    """Reserve limited slots and inventory in priority order."""
    result = prescriptions.copy()
    stock_remaining = inventory.set_index(
        ["workshop_region", "part_name"]
    )["stock_on_hand"].to_dict()

    result["parts_available"] = True
    result["scheduled_window"] = "Backlog / customer choice"
    result["execution_status"] = "Recommendation generated"

    for region in capacity["workshop_region"]:
        candidates = result[result["workshop_region"] == region].sort_values(
            ["priority_rank", "priority_score"], ascending=[True, False]
        )
        capacity_row = capacity[capacity["workshop_region"] == region].iloc[0]
        today_remaining = int(capacity_row["slots_today"])
        next_48h_remaining = int(capacity_row["slots_next_48h"])

        for index, row in candidates.iterrows():
            parts = (
                []
                if row["required_parts"] == "None"
                else [part.strip() for part in row["required_parts"].split(",")]
            )
            parts_are_available = all(
                stock_remaining.get((region, part), 0) > 0 for part in parts
            )
            result.at[index, "parts_available"] = parts_are_available

            # Priority 1-3 cases need a near-term workshop slot.
            if int(row["priority_rank"]) > 3:
                continue

            if not parts_are_available:
                result.at[index, "execution_status"] = "Parts escalation required"
                result.at[index, "decision_reason"] = (
                    str(row["decision_reason"])
                    + "; transfer stock or redirect workshop"
                )
                continue

            if today_remaining > 0:
                result.at[index, "scheduled_window"] = "Today"
                result.at[index, "execution_status"] = "Slot reserved"
                today_remaining -= 1
            elif next_48h_remaining > 0:
                result.at[index, "scheduled_window"] = "Next 48 hours"
                result.at[index, "execution_status"] = "Slot reserved"
                next_48h_remaining -= 1
            else:
                result.at[index, "scheduled_window"] = "Capacity escalation"
                result.at[index, "execution_status"] = (
                    "Capacity escalation required"
                )
                continue

            for part in parts:
                stock_remaining[(region, part)] = (
                    stock_remaining.get((region, part), 0) - 1
                )

    result["predicted_failure_probability"] = result[
        "predicted_failure_probability"
    ].round(4)
    return result.sort_values(
        ["priority_rank", "priority_score"], ascending=[True, False]
    )


def create_summary_reports(result: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Create management-level risk and workshop summaries."""
    risk_summary = result.groupby("risk_category", as_index=False).agg(
        vehicles=("vehicle_id", "count"),
        avg_failure_probability=("predicted_failure_probability", "mean"),
        expected_savings_inr=("expected_savings_inr", "sum"),
    )
    risk_order = pd.CategoricalDtype(
        ["Critical", "High", "Medium", "Low"], ordered=True
    )
    risk_summary["risk_category"] = risk_summary["risk_category"].astype(
        risk_order
    )
    risk_summary = risk_summary.sort_values("risk_category")
    risk_summary["avg_failure_probability"] = risk_summary[
        "avg_failure_probability"
    ].round(3)
    risk_summary["expected_savings_inr"] = risk_summary[
        "expected_savings_inr"
    ].round(2)

    region_summary = result.groupby("workshop_region", as_index=False).agg(
        vehicles=("vehicle_id", "count"),
        critical_high=("priority_rank", lambda values: int((values <= 2).sum())),
        slots_reserved=(
            "execution_status",
            lambda values: int((values == "Slot reserved").sum()),
        ),
        parts_escalations=(
            "execution_status",
            lambda values: int((values == "Parts escalation required").sum()),
        ),
        capacity_escalations=(
            "execution_status",
            lambda values: int(
                (values == "Capacity escalation required").sum()
            ),
        ),
        expected_savings_inr=("expected_savings_inr", "sum"),
    )
    region_summary["expected_savings_inr"] = region_summary[
        "expected_savings_inr"
    ].round(2)
    return risk_summary, region_summary


def main() -> None:
    vehicles, capacity, inventory = load_inputs()
    model, metrics = train_risk_model(vehicles)
    prescriptions = build_prescriptions(vehicles, model)
    result = allocate_resources(prescriptions, capacity, inventory)
    risk_summary, region_summary = create_summary_reports(result)

    result.to_csv(ACTION_REPORT_FILE, index=False)
    risk_summary.to_csv(RISK_SUMMARY_FILE, index=False)
    region_summary.to_csv(REGION_SUMMARY_FILE, index=False)
    METRICS_FILE.write_text(json.dumps(metrics, indent=2), encoding="utf-8")

    summary_lines = [
        "Prescriptive analytics completed successfully.",
        f"Vehicles processed: {len(result):,}",
        f"Model accuracy: {metrics['accuracy']:.3f}",
        f"Model ROC-AUC: {metrics['roc_auc']:.3f}",
        f"Critical/High cases: {(result['priority_rank'] <= 2).sum():,}",
        f"Reserved slots: {(result['execution_status'] == 'Slot reserved').sum():,}",
        "Expected savings: INR "
        f"{result['expected_savings_inr'].sum():,.2f}",
        f"Action report: {ACTION_REPORT_FILE}",
    ]
    RUN_SUMMARY_FILE.write_text("\n".join(summary_lines) + "\n", encoding="utf-8")
    print("\n".join(summary_lines))


if __name__ == "__main__":
    main()

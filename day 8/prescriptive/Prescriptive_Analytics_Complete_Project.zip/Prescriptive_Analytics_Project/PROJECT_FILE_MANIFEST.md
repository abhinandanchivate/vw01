# Project File Manifest

## Root files

| File | Purpose |
|---|---|
| `README_FIRST.md` | Starting point, folder guide, run commands, and verified result |
| `run_analysis.sh` | One-command macOS/Linux execution |
| `run_analysis.bat` | One-command Windows execution |
| `PROJECT_FILE_MANIFEST.md` | Description of every important file group |
| `SHA256SUMS.txt` | File-integrity checksums |

## `case_study_doc/`

Contains the complete case study in PDF, editable Word, and Markdown formats. The document covers the business problem, 5W1H, architecture, decision logic, constraints, worked calculation, expected-value method, KPIs, results, risks, and production roadmap.

## `dataset/`

| File | Purpose |
|---|---|
| `vehicle_prescriptive_input.csv` | 500 vehicle records used for model training and prescriptions |
| `workshop_capacity.csv` | Available regional service slots and mobile technicians |
| `parts_inventory.csv` | Regional stock of brake kits, batteries, and engine sensors |
| `data_dictionary.csv` | Field names, data types, definitions, and examples |
| `sample_case_vehicle.json` | Single-vehicle example for explanation or API prototyping |

## `source_code/`

| File | Purpose |
|---|---|
| `prescriptive_analytics_solution.py` | Complete reusable Python implementation |
| `prescriptive_analytics_notebook.ipynb` | Step-by-step Jupyter/Colab workflow |
| `validate_project.py` | Automated checks for required files, row counts, probabilities, summaries, and metrics |
| `requirements.txt` | Python package dependencies |

## `output/`

Contains all generated reports and presentation-ready deliverables. The Python script regenerates the CSV and JSON reports here without requiring manual path changes.

## `supporting_files/`

Contains architecture images and editable Graphviz source, the decision-flow diagram, business requirements, test cases, and Colab/Jupyter execution instructions.

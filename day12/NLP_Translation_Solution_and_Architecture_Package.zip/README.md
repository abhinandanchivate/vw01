# NLP Translation Solution

This package implements English-to-Hindi and English-to-French translation for automobile customer-support messages.

## Files

- `NLP_Translation_Solution_and_Architecture.docx` - full solution and architecture document
- `translation_architecture.png` - production architecture
- `seq2seq_attention_architecture.png` - educational LSTM/GRU attention architecture
- `translation_solution.py` - single-text and CSV translation
- `evaluate_translation.py` - BLEU and chrF evaluation
- `sample_translation_dataset.csv` - sample parallel dataset
- `requirements.txt` - dependencies

## Setup

```bash
python -m venv .venv
source .venv/bin/activate       # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

The first execution downloads the selected model from Hugging Face.

## Translate one sentence

```bash
python translation_solution.py --target hi --text "My car is not starting."
python translation_solution.py --target fr --text "The brake pedal is not responding properly."
```

## Translate a CSV

```bash
python translation_solution.py \
  --target hi \
  --input-csv sample_translation_dataset.csv \
  --output-csv hindi_output.csv
```

## Evaluate

```bash
python evaluate_translation.py \
  --target hi \
  --dataset sample_translation_dataset.csv \
  --output hindi_evaluation.csv
```

## Notes

- Model IDs: `Helsinki-NLP/opus-mt-en-hi` and `Helsinki-NLP/opus-mt-en-fr`.
- Dates, times, phone numbers, registration-like identifiers, and known vehicle models are protected with placeholders before translation.
- Critical safety complaints and low-confidence generations are sent for human review.

"""Evaluate Hindi/French translations using corpus BLEU and chrF.

Expected columns:
- english_text
- hindi_reference
- french_reference
"""

from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd
from sacrebleu.metrics import BLEU, CHRF

from translation_solution import MarianTranslator


def evaluate(dataset_path: Path, target: str, output_path: Path) -> None:
    data = pd.read_csv(dataset_path)
    reference_column = "hindi_reference" if target == "hi" else "french_reference"
    required = {"english_text", reference_column}
    missing = required.difference(data.columns)
    if missing:
        raise ValueError(f"Missing required columns: {sorted(missing)}")

    translator = MarianTranslator(target)
    predictions = [
        translator.translate(text).translated_text
        for text in data["english_text"].fillna("").astype(str)
    ]
    references = data[reference_column].fillna("").astype(str).tolist()

    bleu = BLEU().corpus_score(predictions, [references])
    chrf = CHRF().corpus_score(predictions, [references])

    result = data[["english_text", reference_column]].copy()
    result["prediction"] = predictions
    result["bleu_corpus_score"] = round(bleu.score, 4)
    result["chrf_corpus_score"] = round(chrf.score, 4)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    result.to_csv(output_path, index=False, encoding="utf-8-sig")

    print(f"BLEU: {bleu.score:.4f}")
    print(f"chrF: {chrf.score:.4f}")
    print(f"Detailed output: {output_path.resolve()}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", type=Path, default=Path("sample_translation_dataset.csv"))
    parser.add_argument("--target", choices=["hi", "fr"], required=True)
    parser.add_argument("--output", type=Path, default=Path("evaluation_results.csv"))
    args = parser.parse_args()
    evaluate(args.dataset, args.target, args.output)


if __name__ == "__main__":
    main()

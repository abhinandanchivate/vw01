"""NLP translation solution for automobile customer-support messages.

Translates English text into Hindi or French using MarianMT models.
It also preserves dates/numbers/model names, assigns a basic support category
and priority, estimates generation confidence, and flags messages for review.

First run downloads model files from Hugging Face.
"""

from __future__ import annotations

import argparse
import json
import re
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple

import pandas as pd
import torch
from transformers import AutoModelForSeq2SeqLM, AutoTokenizer


MODEL_CONFIG: Dict[str, Dict[str, str]] = {
    "hi": {
        "name": "Hindi",
        "model_id": "Helsinki-NLP/opus-mt-en-hi",
    },
    "fr": {
        "name": "French",
        "model_id": "Helsinki-NLP/opus-mt-en-fr",
    },
}

# Business-owned glossary. Extend this using approved terminology.
GLOSSARY = {
    "hi": {
        "brake pedal": "ब्रेक पैडल",
        "battery": "बैटरी",
        "engine": "इंजन",
        "service centre": "सर्विस सेंटर",
        "air conditioner": "एयर कंडीशनर",
        "roadside assistance": "सड़क किनारे सहायता",
    },
    "fr": {
        "brake pedal": "pédale de frein",
        "battery": "batterie",
        "engine": "moteur",
        "service centre": "centre de service",
        "air conditioner": "climatiseur",
        "roadside assistance": "assistance routière",
    },
}

KNOWN_MODELS = [
    "Volkswagen Taigun",
    "Volkswagen Virtus",
    "Tata Nexon",
    "Mahindra XUV700",
    "Hyundai Creta",
    "Maruti Suzuki Baleno",
]

CRITICAL_TERMS = {
    "brake failed",
    "brakes failed",
    "brakes stopped",
    "fire",
    "smoke",
    "accident",
    "steering locked",
    "fuel leak",
    "immediate assistance",
    "emergency",
}

CATEGORY_RULES: Sequence[Tuple[str, Sequence[str]]] = (
    ("Brake Issue", ("brake", "pedal", "braking")),
    ("Battery Issue", ("battery", "not starting", "won't start", "does not start")),
    ("Engine Issue", ("engine", "warning light", "overheating")),
    ("AC Issue", ("air conditioner", "ac ", "cooling")),
    ("Tyre Issue", ("tyre", "tire", "puncture")),
    ("Appointment", ("appointment", "schedule", "book service")),
    ("Billing", ("bill", "invoice", "charged", "payment")),
    ("Warranty", ("warranty", "claim")),
    ("Roadside Assistance", ("roadside", "stranded", "towing")),
)


@dataclass
class TranslationResult:
    source_language: str
    target_language: str
    original_text: str
    translated_text: str
    category: str
    priority: str
    confidence_score: float
    preserved_values: List[str]
    review_required: bool
    review_reasons: List[str]


class PlaceholderProtector:
    """Temporarily protects business-sensitive values from translation."""

    _patterns = [
        # Dates such as 25 June 2026, 25/06/2026, or 2026-06-25
        re.compile(r"\b(?:\d{1,2}[/-]\d{1,2}[/-]\d{2,4}|\d{4}-\d{2}-\d{2})\b"),
        re.compile(
            r"\b\d{1,2}\s+(?:January|February|March|April|May|June|July|August|"
            r"September|October|November|December)(?:\s+\d{4})?\b",
            re.IGNORECASE,
        ),
        # Times
        re.compile(r"\b\d{1,2}:\d{2}\s*(?:AM|PM)?\b", re.IGNORECASE),
        # Phone numbers / registration-like identifiers
        re.compile(r"\b(?:\+?\d[\d\s-]{7,}\d)\b"),
        re.compile(r"\b[A-Z]{2}\s?\d{1,2}\s?[A-Z]{1,3}\s?\d{3,4}\b"),
    ]

    def __init__(self, known_models: Sequence[str] | None = None) -> None:
        self.known_models = list(known_models or KNOWN_MODELS)

    def protect(self, text: str) -> Tuple[str, Dict[str, str]]:
        replacements: Dict[str, str] = {}
        protected = text

        # Longest model names first to prevent partial replacement.
        for value in sorted(self.known_models, key=len, reverse=True):
            protected, replacements = self._replace_literal(
                protected, value, replacements
            )

        for pattern in self._patterns:
            matches = list(pattern.finditer(protected))
            for match in reversed(matches):
                value = match.group(0)
                token = self._new_token(len(replacements))
                replacements[token] = value
                protected = protected[: match.start()] + token + protected[match.end() :]

        return protected, replacements

    @staticmethod
    def _replace_literal(
        text: str, value: str, replacements: Dict[str, str]
    ) -> Tuple[str, Dict[str, str]]:
        pattern = re.compile(re.escape(value), re.IGNORECASE)
        while True:
            match = pattern.search(text)
            if not match:
                break
            token = PlaceholderProtector._new_token(len(replacements))
            replacements[token] = match.group(0)
            text = text[: match.start()] + token + text[match.end() :]
        return text, replacements

    @staticmethod
    def _new_token(index: int) -> str:
        # Alphabetic marker is more stable than punctuation-heavy placeholders.
        return f"ZXQPROTECTED{index}QXZ"

    @staticmethod
    def restore(text: str, replacements: Dict[str, str]) -> str:
        restored = text
        for token, value in replacements.items():
            # Models sometimes insert spaces within a marker; accept that form too.
            compact_pattern = re.compile(r"\s*".join(map(re.escape, token)), re.IGNORECASE)
            restored = compact_pattern.sub(value, restored)
            restored = restored.replace(token, value)
        return restored


class MarianTranslator:
    """Lazy-loading English-to-Hindi/French translator."""

    def __init__(self, target_language: str, device: str | None = None) -> None:
        if target_language not in MODEL_CONFIG:
            supported = ", ".join(MODEL_CONFIG)
            raise ValueError(f"Unsupported target language. Choose one of: {supported}")

        self.target_language = target_language
        self.config = MODEL_CONFIG[target_language]
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        self.protector = PlaceholderProtector()

        model_id = self.config["model_id"]
        self.tokenizer = AutoTokenizer.from_pretrained(model_id)
        self.model = AutoModelForSeq2SeqLM.from_pretrained(model_id).to(self.device)
        self.model.eval()

    def translate(self, text: str, max_new_tokens: int = 128) -> TranslationResult:
        cleaned = normalize_text(text)
        if not cleaned:
            raise ValueError("Input text cannot be empty.")

        protected_text, replacements = self.protector.protect(cleaned)
        model_inputs = self.tokenizer(
            protected_text,
            return_tensors="pt",
            truncation=True,
            max_length=256,
        ).to(self.device)

        with torch.inference_mode():
            generated = self.model.generate(
                **model_inputs,
                max_new_tokens=max_new_tokens,
                num_beams=4,
                early_stopping=True,
                return_dict_in_generate=True,
                output_scores=True,
            )

        raw_translation = self.tokenizer.decode(
            generated.sequences[0], skip_special_tokens=True
        )
        translated = self.protector.restore(raw_translation, replacements)
        translated = apply_glossary_postprocessing(
            source_text=cleaned,
            translated_text=translated,
            language=self.target_language,
        )

        confidence = generation_confidence(self.model, generated)
        category, priority = classify_support_message(cleaned)
        review_reasons = build_review_reasons(
            original=cleaned,
            translation=translated,
            confidence=confidence,
            preserved=list(replacements.values()),
            priority=priority,
        )

        return TranslationResult(
            source_language="English",
            target_language=self.config["name"],
            original_text=cleaned,
            translated_text=translated,
            category=category,
            priority=priority,
            confidence_score=round(confidence, 4),
            preserved_values=list(replacements.values()),
            review_required=bool(review_reasons),
            review_reasons=review_reasons,
        )

    def translate_batch(self, texts: Iterable[str]) -> List[TranslationResult]:
        return [self.translate(text) for text in texts]


def normalize_text(text: str) -> str:
    text = re.sub(r"<[^>]+>", " ", str(text))
    text = re.sub(r"\s+", " ", text).strip()
    text = re.sub(r"([!?.,])\1+", r"\1", text)
    return text


def generation_confidence(model, generated) -> float:
    """Approximate confidence using the geometric mean token probability."""
    if not generated.scores:
        return 0.0
    transition_scores = model.compute_transition_scores(
        generated.sequences,
        generated.scores,
        generated.beam_indices,
        normalize_logits=True,
    )
    valid_scores = transition_scores[0][torch.isfinite(transition_scores[0])]
    if valid_scores.numel() == 0:
        return 0.0
    return float(torch.exp(valid_scores.mean()).clamp(0, 1).item())


def apply_glossary_postprocessing(
    source_text: str, translated_text: str, language: str
) -> str:
    """Applies conservative terminology corrections when a source term exists.

    A production system should use constrained decoding or a translation memory.
    This simple postprocessor is intentionally transparent for training use.
    """
    result = translated_text
    source_lower = source_text.lower()
    glossary = GLOSSARY.get(language, {})

    # Only ensure a preferred term is present when the source used that concept.
    # We avoid aggressive replacements because generated synonyms vary.
    for source_term, preferred in glossary.items():
        if source_term in source_lower and preferred.lower() not in result.lower():
            # Add a terminology note rather than corrupting a grammatical sentence.
            result = f"{result} [Term: {preferred}]"
    return result


def classify_support_message(text: str) -> Tuple[str, str]:
    lowered = text.lower()
    category = "General Feedback"
    for candidate, keywords in CATEGORY_RULES:
        if any(keyword in lowered for keyword in keywords):
            category = candidate
            break

    if any(term in lowered for term in CRITICAL_TERMS):
        priority = "Critical"
    elif any(word in lowered for word in ("not working", "not starting", "failed", "urgent")):
        priority = "High"
    elif category in {"Appointment", "Billing", "Warranty"}:
        priority = "Medium"
    else:
        priority = "Low"
    return category, priority


def build_review_reasons(
    original: str,
    translation: str,
    confidence: float,
    preserved: Sequence[str],
    priority: str,
) -> List[str]:
    reasons: List[str] = []
    if confidence < 0.55:
        reasons.append("Low model confidence")
    if priority == "Critical":
        reasons.append("Critical safety complaint")
    missing = [value for value in preserved if value not in translation]
    if missing:
        reasons.append(f"Preserved value missing: {', '.join(missing)}")
    if not translation.strip() or translation.strip().lower() == original.strip().lower():
        reasons.append("Translation appears empty or unchanged")
    return reasons


def translate_csv(
    input_path: Path,
    output_path: Path,
    target_language: str,
    text_column: str = "english_text",
) -> None:
    data = pd.read_csv(input_path)
    if text_column not in data.columns:
        raise ValueError(
            f"Column '{text_column}' not found. Available columns: {list(data.columns)}"
        )

    translator = MarianTranslator(target_language)
    results = translator.translate_batch(data[text_column].fillna("").astype(str))
    result_df = pd.DataFrame([asdict(result) for result in results])
    output_path.parent.mkdir(parents=True, exist_ok=True)
    result_df.to_csv(output_path, index=False, encoding="utf-8-sig")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Translate English support messages.")
    parser.add_argument("--target", choices=sorted(MODEL_CONFIG), required=True)
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--text", help="Single English sentence")
    group.add_argument("--input-csv", type=Path, help="CSV containing English text")
    parser.add_argument("--output-csv", type=Path, default=Path("translation_output.csv"))
    parser.add_argument("--text-column", default="english_text")
    return parser


def main() -> None:
    args = build_parser().parse_args()
    if args.text:
        result = MarianTranslator(args.target).translate(args.text)
        print(json.dumps(asdict(result), ensure_ascii=False, indent=2))
    else:
        translate_csv(
            input_path=args.input_csv,
            output_path=args.output_csv,
            target_language=args.target,
            text_column=args.text_column,
        )
        print(f"Saved translations to: {args.output_csv.resolve()}")


if __name__ == "__main__":
    main()

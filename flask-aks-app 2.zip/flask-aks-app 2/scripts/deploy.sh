#!/usr/bin/env bash
# ============================================================
# deploy.sh — Provision Azure Resources + Deploy Flask App
# Usage:
#   ./scripts/deploy.sh dev   1.0.0
#   ./scripts/deploy.sh prod  1.2.3
#
# What this script does:
#   1. Creates Resource Group (if not exists)
#   2. Creates ACR (if not exists)
#   3. Creates AKS Cluster (if not exists)
#   4. Attaches ACR to AKS (AcrPull role)
#   5. Builds & pushes Docker image
#   6. Deploys via Helm
# ============================================================
set -euo pipefail

# ── CONFIG ───────────────────────────────────────────────────
ENV=${1:-dev}
TAG=${2:-latest}

RESOURCE_GROUP="rg_sb_eastus_320672_1_178099505793"
LOCATION="eastus"
ACR_NAME="flaskappacr320672"           # must be globally unique, alphanumeric only
IMAGE_REPO="${ACR_NAME}.azurecr.io/flask-app"

# Per-environment cluster names
if [[ "$ENV" == "prod" ]]; then
  AKS_CLUSTER="aks-flask-prod"
  NAMESPACE="flask-prod"
  RELEASE_NAME="flask-app-prod"
  NODE_COUNT=3
  NODE_VM="Standard_D2s_v3"
elif [[ "$ENV" == "dev" ]]; then
  AKS_CLUSTER="aks-flask-dev"
  NAMESPACE="flask-dev"
  RELEASE_NAME="flask-app-dev"
  NODE_COUNT=1
  NODE_VM="Standard_B2s"
else
  echo "ERROR: ENV must be 'dev' or 'prod'. Got: $ENV"
  exit 1
fi

# ── HELPER ───────────────────────────────────────────────────
log() { echo ""; echo "====> $*"; }

# ── STEP 1: Check Azure CLI login ────────────────────────────
log "Checking Azure CLI login..."
az account show > /dev/null 2>&1 || {
  echo "Not logged in. Running az login..."
  az login
}
SUBSCRIPTION_ID=$(az account show --query id -o tsv)
echo "Subscription: $SUBSCRIPTION_ID"

# ── STEP 2: Create Resource Group (idempotent) ───────────────
log "Creating Resource Group: $RESOURCE_GROUP"
az group create \
  --name "$RESOURCE_GROUP" \
  --location "$LOCATION" \
  --output table

# ── STEP 3: Create Azure Container Registry ──────────────────
log "Creating ACR: $ACR_NAME"
az acr create \
  --resource-group "$RESOURCE_GROUP" \
  --name "$ACR_NAME" \
  --sku Basic \
  --admin-enabled false \
  --location "$LOCATION" \
  --output table 2>/dev/null || echo "ACR $ACR_NAME already exists, skipping."

# ── STEP 4: Create AKS Cluster ───────────────────────────────
log "Creating AKS Cluster: $AKS_CLUSTER (nodes=$NODE_COUNT, vm=$NODE_VM)"
az aks create \
  --resource-group "$RESOURCE_GROUP" \
  --name "$AKS_CLUSTER" \
  --node-count "$NODE_COUNT" \
  --node-vm-size "$NODE_VM" \
  --generate-ssh-keys \
  --network-plugin azure \
  --network-policy azure \
  --load-balancer-sku standard \
  --enable-managed-identity \
  --os-disk-size-gb 50 \
  --location "$LOCATION" \
  --output table 2>/dev/null || echo "AKS $AKS_CLUSTER already exists, skipping."

# ── STEP 5: Attach ACR to AKS (grants AcrPull) ───────────────
log "Attaching ACR to AKS (AcrPull role)..."
az aks update \
  --resource-group "$RESOURCE_GROUP" \
  --name "$AKS_CLUSTER" \
  --attach-acr "$ACR_NAME" \
  --output table

# ── STEP 6: Build & Push Docker Image ────────────────────────
log "Logging into ACR and building image..."
az acr login --name "$ACR_NAME"

FULL_IMAGE="${IMAGE_REPO}:${TAG}"
echo "Building: $FULL_IMAGE"
docker build -t "$FULL_IMAGE" .

echo "Pushing: $FULL_IMAGE"
docker push "$FULL_IMAGE"

# Also tag as env-specific
ENV_IMAGE="${IMAGE_REPO}:${ENV}-latest"
docker tag "$FULL_IMAGE" "$ENV_IMAGE"
docker push "$ENV_IMAGE"

# ── STEP 7: Get AKS Credentials ──────────────────────────────
log "Fetching AKS credentials..."
az aks get-credentials \
  --resource-group "$RESOURCE_GROUP" \
  --name "$AKS_CLUSTER" \
  --overwrite-existing

echo "Current context: $(kubectl config current-context)"

# ── STEP 8: Create Namespace ─────────────────────────────────
log "Creating namespace: $NAMESPACE"
kubectl create namespace "$NAMESPACE" --dry-run=client -o yaml | kubectl apply -f -

# ── STEP 9: Helm Deploy ───────────────────────────────────────
log "Running Helm deploy (release=$RELEASE_NAME, env=$ENV, tag=$TAG)..."
helm upgrade --install "$RELEASE_NAME" ./helm/flask-app \
  -f ./helm/flask-app/values.yaml \
  -f "./helm/flask-app/environments/${ENV}/values.yaml" \
  --namespace "$NAMESPACE" \
  --set "image.repository=${IMAGE_REPO}" \
  --set "image.tag=${TAG}" \
  --wait --timeout 10m \
  --atomic

# ── STEP 10: Verify Deployment ───────────────────────────────
log "Checking rollout status..."
kubectl rollout status deployment/"$RELEASE_NAME"-flask-app -n "$NAMESPACE" || true

log "Pods:"
kubectl get pods -n "$NAMESPACE" -l "app.kubernetes.io/instance=$RELEASE_NAME"

log "Service:"
kubectl get svc -n "$NAMESPACE" -l "app.kubernetes.io/instance=$RELEASE_NAME"

log "External LoadBalancer IP:"
for i in {1..12}; do
  EXTERNAL_IP=$(kubectl get svc -n "$NAMESPACE" \
    -l "app.kubernetes.io/instance=$RELEASE_NAME" \
    -o jsonpath='{.items[0].status.loadBalancer.ingress[0].ip}' 2>/dev/null || true)
  if [[ -n "$EXTERNAL_IP" ]]; then
    echo "  http://${EXTERNAL_IP}"
    break
  fi
  echo "  Waiting for IP... ($i/12)"
  sleep 10
done

echo ""
echo "✅  Done! Flask app deployed to $ENV environment."
echo ""

# Flask App on Azure AKS with Helm

A production-ready Flask application deployable to Azure Kubernetes Service (AKS) via Helm, with **two isolated environments (dev / prod)**, security hardening, and an Azure LoadBalancer.

---

## 📁 Project Structure

```
flask-aks-app/
├── app/
│   ├── app.py                     # Flask application
│   └── requirements.txt
├── helm/
│   └── flask-app/
│       ├── Chart.yaml
│       ├── values.yaml            # Base values (all envs)
│       ├── environments/
│       │   ├── dev/values.yaml    # DEV overrides
│       │   └── prod/values.yaml   # PROD overrides
│       └── templates/
│           ├── _helpers.tpl
│           ├── deployment.yaml
│           ├── service.yaml       # LoadBalancer service
│           ├── hpa.yaml           # Horizontal Pod Autoscaler
│           ├── networkpolicy.yaml # Restrict pod traffic
│           ├── pdb.yaml           # Pod Disruption Budget
│           └── serviceaccount.yaml
├── terraform/
│   └── main.tf                    # AKS + ACR + Log Analytics
├── scripts/
│   └── deploy.sh                  # One-command deploy helper
├── .github/workflows/
│   └── deploy.yml                 # GitHub Actions CI/CD
├── Dockerfile                     # Multi-stage, non-root build
├── docker-compose.yml             # Local dev
└── README.md
```

---

## 🚀 Quick Start

### 1. Local Development

```bash
docker-compose up --build
# App available at http://localhost:5000
```

### 2. Provision Azure Infrastructure (Terraform)

```bash
cd terraform

# DEV
terraform workspace new dev
terraform apply -var="environment=dev"

# PROD
terraform workspace new prod
terraform apply -var="environment=prod"
```

### 3. Build & Push Docker Image

```bash
# Login to ACR
az acr login --name myacr

# Build and push
docker build -t myacr.azurecr.io/flask-app:1.0.0 .
docker push myacr.azurecr.io/flask-app:1.0.0
```

### 4. Deploy with Helm

```bash
# DEV
./scripts/deploy.sh dev latest

# PROD
./scripts/deploy.sh prod 1.0.0
```

---

## 🌐 Environments

| Feature                | DEV                          | PROD                        |
|------------------------|------------------------------|-----------------------------|
| Replicas               | 1                            | 3 (+ HPA up to 10)          |
| LoadBalancer           | **Internal** (private VNet)  | **Public**                  |
| Image tag              | `latest`                     | pinned (e.g. `1.0.0`)       |
| Resources              | 50m CPU / 64Mi RAM           | 200m CPU / 128Mi RAM        |
| Pod Disruption Budget  | ❌                            | ✅ minAvailable: 2           |
| Autoscaling (HPA)      | ❌                            | ✅ CPU target 70%            |
| Anti-affinity          | ❌                            | ✅ spread across nodes       |

---

## 🔒 Security Controls

| Control                      | Implementation                                  |
|------------------------------|-------------------------------------------------|
| Non-root container           | `runAsUser: 1001`, `runAsNonRoot: true`         |
| Read-only root filesystem    | `readOnlyRootFilesystem: true` + `/tmp` emptyDir|
| Drop all capabilities        | `capabilities.drop: [ALL]`                      |
| No privilege escalation      | `allowPrivilegeEscalation: false`               |
| Seccomp profile              | `RuntimeDefault`                                |
| Network Policy               | Ingress on 5000 only; egress DNS + HTTPS only   |
| Rate limiting                | Flask-Limiter (200/day, 50/hour per IP)         |
| No SA token auto-mount       | `automountServiceAccountToken: false`           |
| Minimal base image           | `python:3.12-slim` multi-stage build            |
| Azure Defender for Containers| Enabled via Terraform                           |

---

## ⚖️ LoadBalancer Details

### DEV — Internal LoadBalancer
- Annotation: `service.beta.kubernetes.io/azure-load-balancer-internal: "true"`
- Only accessible within the VNet (no public internet exposure)
- Suitable for developer testing via VPN or private endpoint

### PROD — Public LoadBalancer
- Annotation: `service.beta.kubernetes.io/azure-load-balancer-internal: "false"`
- Exposes port 80 publicly, routes to pods on port 5000
- Assign a static IP by uncommenting `azure-pip-name` in prod values

---

## 📡 API Endpoints

| Method | Path        | Description              |
|--------|-------------|--------------------------|
| GET    | `/`         | App info + environment   |
| GET    | `/health`   | Liveness probe           |
| GET    | `/ready`    | Readiness probe          |
| GET    | `/api/data` | Sample data (rate-limited)|
| POST   | `/api/echo` | Echo JSON payload        |

---

## ⚙️ GitHub Actions CI/CD

- **`develop` branch** → build → deploy to **DEV** (internal LB)
- **`main` branch** → build → deploy to **PROD** (public LB, requires approval)

### Required GitHub Secrets

| Secret              | Description                              |
|---------------------|------------------------------------------|
| `AZURE_CREDENTIALS` | Service principal JSON for `az login`    |

---

## 🔧 Helm Commands Reference

```bash
# Dry-run (preview manifests)
helm template flask-app-dev ./helm/flask-app \
  -f ./helm/flask-app/values.yaml \
  -f ./helm/flask-app/environments/dev/values.yaml

# Rollback
helm rollback flask-app-prod 1 -n flask-prod

# Status
helm status flask-app-prod -n flask-prod

# Uninstall
helm uninstall flask-app-dev -n flask-dev
```

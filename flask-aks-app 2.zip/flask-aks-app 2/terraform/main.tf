terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 3.90"
    }
  }
  backend "azurerm" {
    resource_group_name  = "rg-tfstate"
    storage_account_name = "tfstateflaskapp"
    container_name       = "tfstate"
    key                  = "flask-aks.tfstate"
  }
}

provider "azurerm" {
  features {}
}

variable "environment" {
  description = "Environment name (dev or prod)"
  type        = string
}

variable "location" {
  default = "eastus"
}

locals {
  prefix = "flask-${var.environment}"
  tags = {
    environment = var.environment
    project     = "flask-aks"
    managed_by  = "terraform"
  }
}

# ── Resource Group ──────────────────────────────────────────
resource "azurerm_resource_group" "rg" {
  name     = "rg-${local.prefix}"
  location = var.location
  tags     = local.tags
}

# ── Azure Container Registry ─────────────────────────────────
resource "azurerm_container_registry" "acr" {
  name                = "myacrflaskapp"
  resource_group_name = azurerm_resource_group.rg.name
  location            = azurerm_resource_group.rg.location
  sku                 = var.environment == "prod" ? "Premium" : "Basic"
  admin_enabled       = false
  tags                = local.tags
}

# ── AKS Cluster ──────────────────────────────────────────────
resource "azurerm_kubernetes_cluster" "aks" {
  name                = "aks-${local.prefix}-cluster"
  location            = azurerm_resource_group.rg.location
  resource_group_name = azurerm_resource_group.rg.name
  dns_prefix          = "aks-${local.prefix}"
  kubernetes_version  = "1.29"

  default_node_pool {
    name                = "system"
    node_count          = var.environment == "prod" ? 3 : 1
    vm_size             = var.environment == "prod" ? "Standard_D2s_v3" : "Standard_B2s"
    os_disk_size_gb     = 50
    type                = "VirtualMachineScaleSets"
    enable_auto_scaling = var.environment == "prod"
    min_count           = var.environment == "prod" ? 3 : null
    max_count           = var.environment == "prod" ? 6 : null
  }

  identity {
    type = "SystemAssigned"
  }

  network_profile {
    network_plugin    = "azure"
    network_policy    = "azure"   # Enable NetworkPolicy enforcement
    load_balancer_sku = "standard"
  }

  # Azure Defender for Containers
  microsoft_defender {
    log_analytics_workspace_id = azurerm_log_analytics_workspace.law.id
  }

  oms_agent {
    log_analytics_workspace_id = azurerm_log_analytics_workspace.law.id
  }

  tags = local.tags
}

# ── ACR Pull Role Assignment ─────────────────────────────────
resource "azurerm_role_assignment" "acr_pull" {
  principal_id                     = azurerm_kubernetes_cluster.aks.kubelet_identity[0].object_id
  role_definition_name             = "AcrPull"
  scope                            = azurerm_container_registry.acr.id
  skip_service_principal_aad_check = true
}

# ── Log Analytics ────────────────────────────────────────────
resource "azurerm_log_analytics_workspace" "law" {
  name                = "law-${local.prefix}"
  location            = azurerm_resource_group.rg.location
  resource_group_name = azurerm_resource_group.rg.name
  sku                 = "PerGB2018"
  retention_in_days   = var.environment == "prod" ? 90 : 30
  tags                = local.tags
}

output "aks_name" {
  value = azurerm_kubernetes_cluster.aks.name
}

output "acr_login_server" {
  value = azurerm_container_registry.acr.login_server
}

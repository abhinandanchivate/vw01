import os
import logging
from flask import Flask, jsonify, request
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s"
)
logger = logging.getLogger(__name__)

app = Flask(__name__)

# Rate limiting
limiter = Limiter(
    get_remote_address,
    app=app,
    default_limits=["200 per day", "50 per hour"],
    storage_uri="memory://"
)

ENV = os.environ.get("APP_ENV", "development")
APP_VERSION = os.environ.get("APP_VERSION", "1.0.0")


@app.route("/", methods=["GET"])
def index():
    return jsonify({
        "message": "Flask App on AKS",
        "environment": ENV,
        "version": APP_VERSION,
        "status": "running"
    })


@app.route("/health", methods=["GET"])
def health():
    """Liveness probe endpoint."""
    return jsonify({"status": "healthy"}), 200


@app.route("/ready", methods=["GET"])
def ready():
    """Readiness probe endpoint."""
    return jsonify({"status": "ready"}), 200


@app.route("/api/data", methods=["GET"])
@limiter.limit("30 per minute")
def get_data():
    logger.info(f"Data endpoint hit from {request.remote_addr}")
    return jsonify({
        "environment": ENV,
        "data": [
            {"id": 1, "name": "Item One"},
            {"id": 2, "name": "Item Two"},
            {"id": 3, "name": "Item Three"}
        ]
    })


@app.route("/api/echo", methods=["POST"])
@limiter.limit("20 per minute")
def echo():
    payload = request.get_json(silent=True) or {}
    return jsonify({"echo": payload, "environment": ENV})


@app.errorhandler(404)
def not_found(e):
    return jsonify({"error": "Not found"}), 404


@app.errorhandler(429)
def rate_limited(e):
    return jsonify({"error": "Rate limit exceeded"}), 429


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=(ENV == "development"))

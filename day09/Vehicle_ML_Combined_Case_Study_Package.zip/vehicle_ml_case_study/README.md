# Vehicle Service-Risk ML Case Study

This package combines:

- One-hot encoding for nominal input columns
- Label encoding for the target
- Feature selection with `SelectKBest(mutual_info_classif)`
- PCA retaining at least 95% explained variance
- Automated preprocessing, training, evaluation, persistence, and inference using scikit-learn pipelines

## Recommended reading order

1. `Vehicle_ML_Combined_Case_Study.docx`
2. `docs/architecture.png`
3. `data/vehicle_service_risk_dataset.csv`
4. `src/vehicle_risk_pipeline.py`
5. `outputs/model_comparison.csv`
6. `src/predict_new_data.py`

## Run the complete training workflow

```bash
pip install -r requirements.txt
python src/vehicle_risk_pipeline.py
```

## Run inference on new vehicles

```bash
python src/predict_new_data.py
```

## Main generated outputs

- `outputs/model_comparison.csv`
- `outputs/selected_features.csv`
- `outputs/pca_explained_variance.csv`
- `outputs/sample_predictions.csv`
- `outputs/classification_reports_and_confusion_matrices.json`
- `artifacts/feature_selection_pipeline.joblib`
- `artifacts/pca_pipeline.joblib`
- `artifacts/target_label_encoder.joblib`

The dataset is synthetic and intended for education and demonstration, not operational vehicle-safety decisions.

from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, Tuple

import joblib
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.decomposition import PCA
from sklearn.feature_selection import SelectKBest, mutual_info_classif
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
)
from sklearn.model_selection import StratifiedKFold, cross_val_score, train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import LabelEncoder, OneHotEncoder, StandardScaler

RANDOM_STATE = 42


def generate_dataset(n_rows: int = 1500, random_state: int = RANDOM_STATE) -> pd.DataFrame:
    """Generate a realistic synthetic automobile service-risk dataset."""
    rng = np.random.default_rng(random_state)

    vehicle_age_years = np.clip(rng.normal(5.5, 2.7, n_rows), 0.5, 15).round(1)
    mileage_km = np.clip(
        vehicle_age_years * rng.normal(12500, 2300, n_rows) + rng.normal(0, 11000, n_rows),
        5000,
        220000,
    ).round().astype(int)
    service_gap_months = np.clip(rng.gamma(2.7, 3.2, n_rows), 1, 28).round().astype(int)
    engine_alerts = np.clip(rng.poisson(1.4 + mileage_km / 90000), 0, 12).astype(int)
    brake_wear_percent = np.clip(
        14 + mileage_km / 1800 + rng.normal(0, 11, n_rows), 8, 98
    ).round(1)
    avg_monthly_distance_km = np.clip(rng.normal(1250, 520, n_rows), 200, 3500).round().astype(int)
    warranty_claims = np.clip(rng.poisson(0.35 + vehicle_age_years / 14), 0, 6).astype(int)
    customer_complaints = np.clip(rng.poisson(0.7 + engine_alerts / 4), 0, 8).astype(int)
    repair_cost_last_year = np.clip(
        1500 + vehicle_age_years * 900 + engine_alerts * 1250 + rng.normal(0, 3200, n_rows),
        0,
        55000,
    ).round().astype(int)

    battery_voltage = rng.choice(["Low", "Normal"], n_rows, p=[0.24, 0.76])
    driving_pattern = rng.choice(["City", "Highway", "Mixed"], n_rows, p=[0.48, 0.22, 0.30])
    fuel_type = rng.choice(["Petrol", "Diesel", "CNG", "Electric"], n_rows, p=[0.43, 0.34, 0.13, 0.10])
    region = rng.choice(["West", "North", "South", "East"], n_rows, p=[0.31, 0.24, 0.28, 0.17])
    transmission = rng.choice(["Manual", "Automatic"], n_rows, p=[0.59, 0.41])
    service_center_type = rng.choice(["Authorized", "Independent"], n_rows, p=[0.67, 0.33])

    # Hidden business relationship used only to create the synthetic target.
    risk_score = (
        -6.9
        + 0.000018 * mileage_km
        + 0.15 * service_gap_months
        + 0.31 * engine_alerts
        + 0.027 * brake_wear_percent
        + 0.31 * warranty_claims
        + 0.35 * customer_complaints
        + 0.000025 * repair_cost_last_year
        + 0.58 * (battery_voltage == "Low")
        + 0.37 * (driving_pattern == "City")
        + 0.19 * (fuel_type == "Diesel")
        + 0.22 * (service_center_type == "Independent")
        + 0.00019 * avg_monthly_distance_km
        + rng.normal(0, 0.8, n_rows)
    )
    probability = 1 / (1 + np.exp(-risk_score))
    service_risk = np.where(rng.random(n_rows) < probability, "High Risk", "Low Risk")

    df = pd.DataFrame(
        {
            "vehicle_id": [f"VH{100001 + i}" for i in range(n_rows)],
            "vehicle_age_years": vehicle_age_years,
            "mileage_km": mileage_km,
            "service_gap_months": service_gap_months,
            "engine_alerts": engine_alerts,
            "brake_wear_percent": brake_wear_percent,
            "avg_monthly_distance_km": avg_monthly_distance_km,
            "warranty_claims": warranty_claims,
            "customer_complaints": customer_complaints,
            "repair_cost_last_year": repair_cost_last_year,
            "battery_voltage": battery_voltage,
            "driving_pattern": driving_pattern,
            "fuel_type": fuel_type,
            "region": region,
            "transmission": transmission,
            "service_center_type": service_center_type,
            "service_risk": service_risk,
        }
    )

    # Introduce small amounts of missing data so the automated imputation stage is meaningful.
    missing_columns = [
        "service_gap_months",
        "brake_wear_percent",
        "repair_cost_last_year",
        "battery_voltage",
        "driving_pattern",
        "service_center_type",
    ]
    for column in missing_columns:
        mask = rng.random(n_rows) < 0.025
        df.loc[mask, column] = np.nan

    return df


def build_preprocessor(numeric_features: list[str], categorical_features: list[str]) -> ColumnTransformer:
    numeric_pipeline = Pipeline(
        steps=[
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler()),
        ]
    )
    categorical_pipeline = Pipeline(
        steps=[
            ("imputer", SimpleImputer(strategy="most_frequent")),
            (
                "one_hot",
                OneHotEncoder(handle_unknown="ignore", sparse_output=False),
            ),
        ]
    )

    return ColumnTransformer(
        transformers=[
            ("numeric", numeric_pipeline, numeric_features),
            ("categorical", categorical_pipeline, categorical_features),
        ],
        remainder="drop",
        verbose_feature_names_out=True,
    )


def build_pipelines(
    numeric_features: list[str], categorical_features: list[str]
) -> Dict[str, Pipeline]:
    selector_preprocessor = build_preprocessor(numeric_features, categorical_features)
    pca_preprocessor = build_preprocessor(numeric_features, categorical_features)

    common_model = dict(
        max_iter=3000,
        class_weight="balanced",
        solver="liblinear",
        random_state=RANDOM_STATE,
    )

    return {
        "Feature Selection": Pipeline(
            steps=[
                ("preprocessor", selector_preprocessor),
                (
                    "selector",
                    SelectKBest(score_func=mutual_info_classif, k=10),
                ),
                ("model", LogisticRegression(**common_model)),
            ]
        ),
        "PCA": Pipeline(
            steps=[
                ("preprocessor", pca_preprocessor),
                ("pca", PCA(n_components=0.95, svd_solver="full")),
                ("model", LogisticRegression(**common_model)),
            ]
        ),
    }


def evaluate_model(
    name: str,
    pipeline: Pipeline,
    x_train: pd.DataFrame,
    x_test: pd.DataFrame,
    y_train: np.ndarray,
    y_test: np.ndarray,
    high_risk_code: int,
) -> Tuple[dict, dict]:
    pipeline.fit(x_train, y_train)
    predictions = pipeline.predict(x_test)

    class_order = list(pipeline.named_steps["model"].classes_)
    high_risk_probability_index = class_order.index(high_risk_code)
    probabilities = pipeline.predict_proba(x_test)[:, high_risk_probability_index]

    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=RANDOM_STATE)
    cv_scores = cross_val_score(pipeline, x_train, y_train, cv=cv, scoring="f1_macro")

    metrics = {
        "model": name,
        "accuracy": accuracy_score(y_test, predictions),
        "precision_high_risk": precision_score(
            y_test, predictions, pos_label=high_risk_code, zero_division=0
        ),
        "recall_high_risk": recall_score(
            y_test, predictions, pos_label=high_risk_code, zero_division=0
        ),
        "f1_high_risk": f1_score(
            y_test, predictions, pos_label=high_risk_code, zero_division=0
        ),
        "roc_auc_high_risk": roc_auc_score(
            (y_test == high_risk_code).astype(int), probabilities
        ),
        "cv_f1_macro_mean": cv_scores.mean(),
        "cv_f1_macro_std": cv_scores.std(),
    }

    details = {
        "classification_report": classification_report(
            y_test,
            predictions,
            labels=[high_risk_code, 1 - high_risk_code],
            target_names=["High Risk", "Low Risk"],
            output_dict=True,
            zero_division=0,
        ),
        "confusion_matrix": confusion_matrix(
            y_test, predictions, labels=[high_risk_code, 1 - high_risk_code]
        ).tolist(),
    }
    return metrics, details


def train_and_export(project_root: Path) -> None:
    data_dir = project_root / "data"
    output_dir = project_root / "outputs"
    artifact_dir = project_root / "artifacts"
    data_dir.mkdir(parents=True, exist_ok=True)
    output_dir.mkdir(parents=True, exist_ok=True)
    artifact_dir.mkdir(parents=True, exist_ok=True)

    dataset_path = data_dir / "vehicle_service_risk_dataset.csv"
    if dataset_path.exists():
        df = pd.read_csv(dataset_path)
    else:
        df = generate_dataset()
        df.to_csv(dataset_path, index=False)

    label_encoder = LabelEncoder()
    y = label_encoder.fit_transform(df["service_risk"])
    high_risk_code = int(label_encoder.transform(["High Risk"])[0])

    x = df.drop(columns=["vehicle_id", "service_risk"])
    numeric_features = x.select_dtypes(include=["number"]).columns.tolist()
    categorical_features = x.select_dtypes(exclude=["number"]).columns.tolist()

    x_train, x_test, y_train, y_test = train_test_split(
        x,
        y,
        test_size=0.20,
        random_state=RANDOM_STATE,
        stratify=y,
    )

    pipelines = build_pipelines(numeric_features, categorical_features)
    metrics_rows = []
    model_details = {}

    for name, pipeline in pipelines.items():
        metrics, details = evaluate_model(
            name,
            pipeline,
            x_train,
            x_test,
            y_train,
            y_test,
            high_risk_code,
        )
        metrics_rows.append(metrics)
        model_details[name] = details
        safe_name = name.lower().replace(" ", "_")
        joblib.dump(pipeline, artifact_dir / f"{safe_name}_pipeline.joblib")

    joblib.dump(label_encoder, artifact_dir / "target_label_encoder.joblib")

    comparison = pd.DataFrame(metrics_rows).sort_values(
        by="roc_auc_high_risk", ascending=False
    )
    comparison.to_csv(output_dir / "model_comparison.csv", index=False)

    with (output_dir / "classification_reports_and_confusion_matrices.json").open(
        "w", encoding="utf-8"
    ) as handle:
        json.dump(model_details, handle, indent=2)

    feature_pipeline = pipelines["Feature Selection"]
    all_feature_names = feature_pipeline.named_steps["preprocessor"].get_feature_names_out()
    support_mask = feature_pipeline.named_steps["selector"].get_support()
    scores = feature_pipeline.named_steps["selector"].scores_
    selected_df = pd.DataFrame(
        {
            "transformed_feature": all_feature_names,
            "mutual_information_score": scores,
            "selected": support_mask,
        }
    ).sort_values(["selected", "mutual_information_score"], ascending=[False, False])
    selected_df.to_csv(output_dir / "selected_features.csv", index=False)

    pca_step = pipelines["PCA"].named_steps["pca"]
    pca_df = pd.DataFrame(
        {
            "principal_component": [f"PC{i + 1}" for i in range(pca_step.n_components_)],
            "explained_variance_ratio": pca_step.explained_variance_ratio_,
            "cumulative_explained_variance": np.cumsum(
                pca_step.explained_variance_ratio_
            ),
        }
    )
    pca_df.to_csv(output_dir / "pca_explained_variance.csv", index=False)

    best_name = comparison.iloc[0]["model"]
    best_pipeline = pipelines[best_name]
    sample_x = x_test.head(12).copy()
    sample_pred_code = best_pipeline.predict(sample_x)
    class_order = list(best_pipeline.named_steps["model"].classes_)
    high_idx = class_order.index(high_risk_code)
    sample_probability = best_pipeline.predict_proba(sample_x)[:, high_idx]
    sample_output = sample_x.reset_index(drop=True).copy()
    sample_output.insert(0, "vehicle_id", df.loc[x_test.head(12).index, "vehicle_id"].values)
    sample_output["predicted_service_risk"] = label_encoder.inverse_transform(sample_pred_code)
    sample_output["high_risk_probability"] = sample_probability.round(4)
    sample_output.to_csv(output_dir / "sample_predictions.csv", index=False)

    metadata = {
        "rows": int(len(df)),
        "input_feature_count": int(x.shape[1]),
        "numeric_features": numeric_features,
        "categorical_features": categorical_features,
        "target_classes": label_encoder.classes_.tolist(),
        "label_mapping": {
            label: int(code)
            for label, code in zip(
                label_encoder.classes_, label_encoder.transform(label_encoder.classes_)
            )
        },
        "high_risk_code": high_risk_code,
        "train_rows": int(len(x_train)),
        "test_rows": int(len(x_test)),
        "best_model": str(best_name),
        "pca_components_for_95_percent_variance": int(pca_step.n_components_),
        "transformed_feature_count_before_reduction": int(len(all_feature_names)),
        "selected_feature_count": int(support_mask.sum()),
    }
    with (output_dir / "run_metadata.json").open("w", encoding="utf-8") as handle:
        json.dump(metadata, handle, indent=2)

    print("Training completed.")
    print(comparison.to_string(index=False))
    print(json.dumps(metadata, indent=2))


if __name__ == "__main__":
    root = Path(__file__).resolve().parents[1]
    train_and_export(root)

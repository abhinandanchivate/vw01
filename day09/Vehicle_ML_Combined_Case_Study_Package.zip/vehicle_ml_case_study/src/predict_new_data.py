from pathlib import Path
import joblib
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
MODEL_PATH = ROOT / "artifacts" / "feature_selection_pipeline.joblib"
ENCODER_PATH = ROOT / "artifacts" / "target_label_encoder.joblib"
INPUT_PATH = ROOT / "data" / "new_vehicle_input.csv"
OUTPUT_PATH = ROOT / "outputs" / "new_vehicle_predictions.csv"

pipeline = joblib.load(MODEL_PATH)
label_encoder = joblib.load(ENCODER_PATH)
new_data = pd.read_csv(INPUT_PATH)

prediction_codes = pipeline.predict(new_data)
class_order = list(pipeline.named_steps["model"].classes_)
high_risk_code = int(label_encoder.transform(["High Risk"])[0])
high_risk_probability_index = class_order.index(high_risk_code)

result = new_data.copy()
result["predicted_service_risk"] = label_encoder.inverse_transform(prediction_codes)
result["high_risk_probability"] = pipeline.predict_proba(new_data)[:, high_risk_probability_index].round(4)
result.to_csv(OUTPUT_PATH, index=False)
print(result.to_string(index=False))
print(f"\nSaved predictions to: {OUTPUT_PATH}")

ADVANCED AUTO INDUSTRY DATASET PACKAGE

Case:
Connected Vehicle Component Failure and Service Priority Prediction

Files:
1. Advanced_Auto_Connected_Vehicle_Dataset.csv
   - 25,000 snapshot rows
   - 6,500 vehicles
   - 41 columns
   - Target: service_priority_30d

2. Advanced_Auto_Connected_Vehicle_Dataset.xlsx
   - Overview
   - Vehicle_Data
   - Data_Dictionary
   - Missingness
   - Scoring_Sample

3. Advanced_Auto_Scoring_Sample.csv
   - 250 future scoring rows
   - Target intentionally removed
   - Contains unseen categories to test unknown-category-safe encoding

4. Advanced_Auto_Data_Dictionary.csv
   - Definitions, roles, expected values and missingness notes

Target distribution:
- Routine: 16,250
- Watch: 5,250
- Urgent: 2,500
- Critical: 1,000

Important modelling controls:
- Do not use vehicle_id as a predictive feature.
- Use vehicle_id for group-aware splitting.
- Use snapshot_timestamp for chronological validation.
- charging_cycles_30d is conditionally applicable to EV/Hybrid rows.
- Engine and oil fields are intentionally non-applicable for many EV rows.
- The dataset contains missing values, rare categories, correlated sensors,
  outliers and 30 duplicate vehicle/timestamp key rows.
- The scoring sample contains unseen categories.
- This is synthetic training data and must not be treated as real OEM data.

Random seed: 20260618
